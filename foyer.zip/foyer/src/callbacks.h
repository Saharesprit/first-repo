#include <gtk/gtk.h>


void
on_button1_ajouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button95_afficher_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button63_rechercher_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button88_actualiser_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_supp_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbuttonindiv_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttondouble_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonmodif_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbuttontriiple_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);


void
on_button1_trouver_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
