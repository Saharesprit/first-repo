#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include<string.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"fonction.h"

int x,y;

void
on_button1_ajouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char x[30];
etudiant e;
GtkWidget *input1, *input2,*input3,*input4,*input5;
input1=lookup_widget (objet_graphique, "entry51_nom");
input2 = lookup_widget (objet_graphique, "entry52_prenom");
input3 = lookup_widget (objet_graphique, "entry53_cin");
input4 = lookup_widget (objet_graphique, "entry2_id");
input5=lookup_widget(objet_graphique,"combobox2");
if (x==1){
strcpy(e.sexe,"femme");
}
else {
strcpy(e.sexe,"homme");
}

if (y==1){
strcpy(e.type,"Individuelle");
}
else
if (y==2){
strcpy(e.type,"Double");
}
else {
strcpy(e.type,"Triple");
}
strcpy(e.prenom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.cin, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.id, gtk_entry_get_text(GTK_ENTRY(input4)));
/*sortie2=lookup_widget(objet_graphique, "label97_videchamp");
if (veriff(x)==0)
{gtk_label_set_text(GTK_LABEL(sortie2),"champs obligatoire!");}*/
strcpy(e.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
ajouter_etudiant (e);
}


void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=1;}
}


void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{x=2;}
}


/*void
on_radiobutton5_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=1;}

}


void
on_radiobutton6_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=2;}

}


void
on_radiobutton7_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y=3;}
}
*/

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter ;
gchar* nom ;
gchar* prenom ;
gchar* cin ;
gchar* id ;
gchar* sexe ;
gchar* etage ;
gchar* type ;
etudiant e ;


GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter, path))
{
	gtk_tree_model_get (GTK_LIST_STORE (model), &iter , 0 , &nom ,  1 ,&prenom, 2 , &cin , 3 , &id ,4 ,&sexe, 5 , &etage, 6 , &type,  -1);
	strcpy(e.nom,nom);
	strcpy(e.prenom,prenom);
	strcpy(e.cin,id);
	strcpy(e.id,cin);
	strcpy(e.sexe,sexe);
	strcpy(e.etage,etage);
	strcpy(e.type,type);
	afficher_etudiants(treeview);
}

}

void
on_button95_afficher_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview55;
//fenetre_ajout=lookup_widget(objet_graphique,"Foyer");
fenetre_afficher=lookup_widget(objet_graphique,"Foyer");

treeview55=lookup_widget(fenetre_afficher,"treeview55");
afficher_etudiants(treeview55);

}





void
on_button63_rechercher_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
/*int trouve=0;
GtkWidget *id, *output;
char id1[20];
char msg[100];
id = lookup_widget (objet_graphique, "entry20_rech");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(id)));
output = lookup_widget(objet_graphique, "label81_rech");

trouve=exist_id( id1);

if(trouve==1)
{strcpy (msg,"L'etudiant existe, vous pouvez continuer.");
gtk_label_set_text(GTK_LABEL(output),msg);
}
else if(trouve==0){
strcpy (msg,"l'etudiant n'existe pas, veuillez vérifier.");
gtk_label_set_text(GTK_LABEL(output),msg);}
}*/
etudiant e;
GtkWidget *input11;
GtkWidget *nonexiste;

input11=lookup_widget(objet_graphique,"entry20_rech");
nonexiste=lookup_widget(objet_graphique,"label81_rech");


strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input11)));

if (exist_id(e.id)==0)
{
    gtk_label_set_text(GTK_LABEL(nonexiste),"l'etudiant n'existe pas, veuillez vérifier.");
}
else

{
    gtk_label_set_text(GTK_LABEL(nonexiste),"L'etudiant existe, vous pouvez continuer.");
}

chercher_etudiant(e);
gtk_entry_set_text(GTK_ENTRY(input11),"");
GtkWidget *treeview55;
treeview55=lookup_widget(objet_graphique,"treeview55");
afficher_etudiant_chercher(treeview55);
}


void
on_button88_actualiser_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
/*GtkWidget *fenetre_tableau,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet_graphique,"fenetre_tableau");
fenetre_tableau=create_Foyer();

gtk_widget_show(fenetre_tableau);

gtk_widget_hide(w1);

treeview1=lookup_widget(fenetre_tableau,"treeview55");

afficher_etudiants(treeview1);*/
GtkWidget *Foyer,*fenetre_afficher ;
GtkWidget *treeview55 ;
Foyer=lookup_widget(objet_graphique,"Foyer");
fenetre_afficher=create_Foyer();
gtk_widget_show(fenetre_afficher);
gtk_widget_hide(Foyer);

treeview55=lookup_widget(Foyer,"treeview55");
afficher_etudiants(treeview55);
}


void
on_button13_supp_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
/*GtkWidget *output;
GtkWidget *input1 ;
etudiant e ; 
char id[20];
input1=lookup_widget(objet_graphique,"entry166_supp");
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input1)));
supprimer_etudiant (e);
output=lookup_widget(objet_graphique,"label83_supp");
gtk_label_set_text(GTK_LABEL(output),"supprimé avec succés");*/
char id[20];
int k=0;
GtkWidget *window1 ,*input1;
GtkWidget *output;
etudiant e;
input1=lookup_widget(objet_graphique,"entry166_supp");
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input1)));
output=lookup_widget(objet_graphique,"label83_supp");
k=exist_id(e.id);
if (k==0)
{
gtk_label_set_text(GTK_LABEL(output),"L'etudiant n'existe pas , veuillez verifier");
}
else
{
supprimer_etudiant (e);
gtk_label_set_text(GTK_LABEL(output),"Supprimé avec succés");
}
}


void
on_checkbuttonindiv_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{y=1 ;}
}


void
on_checkbuttondouble_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{y=2 ;}
}



void
on_buttonmodif_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *input1, *input2,*input3,*input4,*input5,*output;
input1=lookup_widget (objet_graphique, "entryid");
input2 = lookup_widget (objet_graphique, "entrynomm");
input3 = lookup_widget (objet_graphique, "entryprenomm");
input4 = lookup_widget (objet_graphique, "entrycinm");
input5=lookup_widget(objet_graphique,"comboboxetagem");
if (x==1){
strcpy(e.sexe,"femme");
}
else {
strcpy(e.sexe,"homme");
}

if (y==1){
strcpy(e.type,"Individuelle");
}
else
if(y==2){
strcpy(e.type,"Double");
}
else{
strcpy(e.type,"Triple");
}
strcpy(e.prenom, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.cin, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.id, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.nom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
modifier_etudiant(e);
output=lookup_widget(objet_graphique,"labelmsgg");
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés");
}


void
on_checkbuttontriiple_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)

{
if (gtk_toggle_button_get_active(togglebutton))
{y=3 ;}
}



void
on_button1_trouver_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
/*int n;
etudiant e;
GtkWidget *input1, *output;
char etage1[20];
input1=lookup_widget (objet_graphique, "entry1_niveau");
output=lookup_widget(objet_graphique,"labelniveau");

strcpy(etage1,gtk_entry_get_text(GTK_ENTRY(input1)));
n=nombre_etudiants(input1);*/
char etage[20];
int n ;
char msg[30];
GtkWidget *input1, *output;
input1=lookup_widget(objet_graphique,"combobox3_nbr");
strcpy(etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
n=nombre_etudiants(etage);
sprintf(msg, "%d", n);
output = lookup_widget(objet_graphique, "labelniveau");
gtk_label_set_text(GTK_LABEL(output),msg);
}

