#ifdef HAVE_CONFIG.H
#include<config.h>
#endif


#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "stock.h"
#include<gtk/gtk.h>


enum
{
	
	CATEGORIE,
	TYPE,
	ID,
	QUANTITE,
	COLUMNS,
};




//**********************************Fonction Ajouter**********************************
void Ajouter_stock(stock s)
{
FILE *f;
f=fopen("stock.txt","a+");
if(f!=NULL)
{
fprintf(f," %s %s %s %d \n",s.categorie,s.type,s.id,s.quantite);
 fclose(f);
}
}
void afficher_stock(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;


	GtkListStore *store;
	char categorie[30];	
	char id[20];
	int quantite;
	char type[30];
	store=NULL;

FILE *f;

store = gtk_tree_view_get_model(liste);

if (store==NULL)
{
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("categorie",renderer,"text",CATEGORIE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer = gtk_cell_renderer_text_new();
column = gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",QUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}
store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);
f=fopen("stock.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("stock.txt","a+");
		while(fscanf(f,"%s %s %s %d \n",categorie,type,id,&quantite)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store, &iter,CATEGORIE, categorie,TYPE,type,ID, id,QUANTITE,quantite, -1);
}
fclose(f);
gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
g_object_unref (store);
}

}
void vider_stock(GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter	iter;
GtkListStore *store;
	
char categorie[30];
char id[30];
int quantite;
char type[30];
store=NULL ;

FILE *f;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" categorie ", renderer , "text",CATEGORIE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" type ", renderer , "text",TYPE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);


		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" id ", renderer , "text",ID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" quantite ", renderer , "text",quantite, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		
}

store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_INT);
gtk_list_store_append (store, &iter);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));

}
void modifier_stock(stock s)
{
FILE *f;
FILE *t;

stock z ;
f=fopen("stock.txt","r");
t=fopen("temp.text","a");

    if (f!=NULL || t!=NULL)
    {

    while(fscanf(f,"%s %s %s %d \n",z.categorie,z.type,z.id,&z.quantite)!=EOF)
    {

if(strcmp(z.id,s.id)==0)
        {
fprintf(t,"%s %s %s %d\n",s.categorie,s.type,s.id,s.quantite);
}
else
fprintf(t,"%s %s %s %d\n",z.categorie,z.type,z.id,z.quantite);
    }
    }

fclose(t);
fclose(f);
remove("stock.txt");
rename("temp.text","stock.txt");
}

void chercher_stock(stock s)  
{
FILE* f;
FILE* f1;
	char categorie[30];
	char id[30];
        int quantite;
	char type[30];
	

f=fopen("stock.txt","r");
f1=fopen("stockcher.txt","w");
  while(fscanf(f,"%s %s %s %d \n",categorie,type,id,&quantite)!=EOF)
{
if (strcmp(s.id,id)==0)
{
fprintf(f1,"%s %s %s %d \n",categorie,type,id,quantite);
}
}
fclose(f);
fclose(f1);
}

void afficher_stock_chercher(GtkWidget *liste)
{
      GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char id[30];
        int quantite;
	char categorie [30];
	char type[30];

	store=NULL;
	
	FILE *f;
 
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("categorie", renderer,"text",CATEGORIE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("type", renderer,"text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("id", renderer,"text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("quantite", renderer,"text",QUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

	}
		store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT);
	f = fopen("stockcher.txt","r");
	if(f==NULL)
	{
	return;
	}
	else
	{
	 f=fopen("stockcher.txt","a+");
		while(fscanf(f,"%s %s %s %d\n",categorie,type,id,&quantite)!=EOF)
		{
		gtk_list_store_append(store,&iter);
		 gtk_list_store_set(store,&iter ,CATEGORIE,categorie,TYPE,type,ID,id,QUANTITE,quantite,-1);		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);

	}
}

int exist_id_stock(char* id){
FILE*f=NULL;
stock s;
f=fopen("stock.txt","r"); 
while(fscanf(f,"%s %s %s %d \n",s.categorie,s.type,s.id,&s.quantite)!=EOF){
if(strcmp(s.id,id)==0)
return 1;   
}
fclose(f);
return 0;
}
void Supprimer_stock(stock s)
{
char categorie[30];
char type[30];
int quantite;
char id[30];
	
FILE *f,*g;
f=fopen("stock.txt","r");
g=fopen("temp.txt","w");
if (f==NULL || g==NULL)
{
return;
}
else
{ 
	while(fscanf(f,"%s %s %s %d \n",categorie,type,id,&quantite)!=EOF)
	{
	if(strcmp(s.categorie,categorie)!=0 || strcmp(s.type,type)!=0 || strcmp(s.id,id)!=0 || s.quantite!=quantite )
	fprintf(g,"%s %s %s %d \n",categorie,type,id,quantite);	
	}
fclose(f);
fclose(g);
remove("stockl.txt");
rename("temp.txt","stock.txt");
}
}

