#include <gtk/gtk.h>
typedef struct
{
char id[20];
int quantite;
char categorie[30];
char type[30];
}stock;
int z,A;
void afficher_stock_chercher(GtkWidget *liste);
void Ajouter_stock(stock s);

int exist_id_stock(char* id);

void chercher_stock(stock s) ;
void modifier_stock(stock s);
void Supprimer_stock(stock s);
void afficher_stock(GtkWidget *liste);
void vider_stock(GtkWidget *liste);
