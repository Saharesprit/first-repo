#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#include<gtk/gtk.h>
typedef struct
{
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char etage[20];
char type[20];
}etudiant;
int m,n;
etudiant e;
void ajouter_etudiant(etudiant e);
void afficher_etudiants(GtkWidget * liste );
void chercher_etudiant(etudiant e);
int exist_id_e(char* id);
void afficher_etudiant_chercher(GtkWidget * liste );
void supprimer_etudiant (etudiant e );
void modifier_etudiant (etudiant e);
int nombre_etudiants (char etage1[20]);
//int veriff(char x[]);
#endif // FONCTION_H_INCLUDED
