#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>
#include "fonction.h"

enum{
NOM,PRENOM,CIN,ID,SEXE,ETAGE,TYPE,COLUMNS
};

void ajouter_etudiant(etudiant e){
FILE *f;
f=fopen("foyer.txt","a+");
if (f!=NULL)
{
fprintf(f," %s %s  %s %s %s %s %s \n",e.nom,e.prenom,e.cin,e.id,e.sexe,e.etage,e.type);
}
fclose(f);
}

void afficher_etudiants(GtkWidget * liste )
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char etage[20];
char type[20];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",ETAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("foyer.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("foyer.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,CIN,cin,ID,id,SEXE,sexe,ETAGE,etage,TYPE,type,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void chercher_etudiant(etudiant e)  
{
FILE* f;
FILE* f1;
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char etage[20];
char type[20];

f=fopen("foyer.txt","r");
f1=fopen("foyerch.txt","w");
while(fscanf(f,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type)!=EOF)
{
if (strcmp(e.id,id)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type);
}
}
fclose(f);
fclose(f1);
}

int exist_id_e(char* id){
/*int trouve=0;*/
/*char nom[20];
char prenom [20];
char cin[20];
char id[20]; 
char sexe [30];
char etage [20];
char type[20];*/
etudiant e;
FILE *f=NULL;
f=fopen("foyer.txt","r");
//if(f!=NULL){
while(fscanf(f,"%s %s %s %s %s %s %s \n",e.nom,e.prenom,e.cin,e.id,e.sexe,e.etage,e.type)!=EOF){
if(strcmp(e.id,id)==0)
//trouve=1;}
return 1;
}
fclose(f);
//return (trouve);
return 0;
}

void afficher_etudiant_chercher(GtkWidget * liste )
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char etage[20];
char type[20];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",ETAGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("foyerch.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("foyerch.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,CIN,cin,ID,id,SEXE,sexe,ETAGE,etage,TYPE,type,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
void supprimer_etudiant (etudiant e )
{

char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char etage[20];
char type[20];
FILE *f,*g  ;

	
	f=fopen("foyer.txt","r");
	g=fopen("foyertemp.txt","w+");
	if(g!= NULL )
		{
	if(f!= NULL )
		{
		while (fscanf(f,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type) != EOF ) 
		{ 
		if(strcmp(e.id,id)!=0 )
		
			fprintf(g,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type); 
			

		}}
		fclose(f);
		fclose(g);
		
	
		remove("foyer.txt");
		rename("foyertemp.txt","foyer.txt");
	
}}

void modifier_etudiant (etudiant e)
{
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char etage[20];
char type[20];
FILE *f ;
FILE *fi ;
f=fopen("foyer.txt","r");
fi=fopen("tempfoyer.txt","w+");
if(f != NULL)
{
if (fi != NULL )
{
while(fscanf(f,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type)!=EOF)
{
if (strcmp(e.id,id)!=0)
{
fprintf(fi,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type);
}
else
{
fprintf(fi," %s %s %s %s %s %s %s \n",e.nom,e.prenom,e.cin,e.id,e.sexe,e.etage,e.type);
}
}}}
fclose(f);
fclose(fi);	
remove("foyer.txt");
rename("tempfoyer.txt","foyer.txt");
}


int nombre_etudiants (char etage1[20])
{
FILE *f=NULL;
int k=0;
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char etage[20];
char type[20];
f=fopen("foyer.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %s %s %s \n",nom,prenom,cin,id,sexe,etage,type)!=EOF)
{
if(strcmp(etage1,etage)==0)
k+=1;}
fclose(f);
}
return (k);
}

 
/*int veriff(char x[])
{  etudiant e;
   int i;
   if (strcmp(x,e.id)==0)
   {
      i=0;
   }
   else
   {
      i=1;
   }
return i;}*/



 
