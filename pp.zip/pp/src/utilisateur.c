#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h> 
#include "utilisateur.h"
enum{
	NOM,
	PRENOM,
	SEXE,
	ID,
	ROLE,
	COLUMNS
};

void ajouter_utilisateur(utilisateur u)
{
FILE *f=NULL;
f=fopen("utilisateur.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s \n",u.nom,u.prenom,u.sexe,u.id,u.role);
}
fclose(f);
}

void afficher_utilisateur(GtkWidget * liste ){

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char nom [20];
char prenom [20];
char sexe[20];
char id[20];
char role[20];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",ROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("utilisateur.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("utilisateur.txt","a+");
while(fscanf(f,"%s %s %s %s %s\n",nom,prenom,sexe,id,role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,SEXE,sexe,ID,id,ROLE,role,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void vider(GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter	iter;
GtkListStore *store;
	
char nom [20];
char prenom [20];
char sexe[20];
char id[20];
char role[20];
store=NULL ;

FILE *f;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" nom ", renderer , "text",NOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" prenom ", renderer , "text",PRENOM, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" sexe ", renderer , "text",SEXE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" id ", renderer , "text",ID, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" role ", renderer , "text",ROLE, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

}

store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING);
gtk_list_store_append (store, &iter);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));

}


void modifier_utilisateur(utilisateur u)
{
utilisateur k;
FILE *f;
FILE *t;
f=fopen("utilisateur.txt","r");
t=fopen("tempmod.text","a");
if (f!=NULL)
{
if(t!=NULL){
while(fscanf(f,"%s %s %s %s %s\n",k.nom,k.prenom,k.sexe,k.id,k.role)!=EOF)
{
if(strcmp(k.id,u.id)==0)
{
fprintf(t,"%s %s %s %s %s\n",u.nom,u.prenom,u.sexe,u.id,u.role);
}
else
fprintf(t,"%s %s %s %s %s\n",k.nom,k.prenom,k.sexe,k.id,k.role);
 }
 }
}
fclose(f);
fclose(t);
remove("utilisateur.txt");
rename("tempmod.text","utilisateur.txt");
}


void rechercher_utilisateur(utilisateur u)
{
FILE* f=NULL;
FILE* f1=NULL;
char nom [20];
char prenom [20];

char sexe[20];
char id[20];
char role[20];

f=fopen("utilisateur.txt","r");
f1=fopen("utilisateurcher.txt","w");
  while(fscanf(f,"%s %s %s %s %s\n",nom,prenom,sexe,id,role)!=EOF)
{
if (strcmp(u.id,id)==0)
{
fprintf(f1,"%s %s %s %s %s\n",nom,prenom,sexe,id,role);
}
}
fclose(f);
fclose(f1);
}
/*
char nom [20];
char prenom [20];

char sexe[20];
char id[20];
char role[20];
FILE* f,*g;
f=fopen("utilisateur.txt","r");
g=fopen("utilisateurcher.txt","w");
if(f==NULL || g=NULL)
{
return;}
else
{
while(fscanf(f,"%s %s %s %s %s\n",nom,prenom,sexe,id,role,u.nom,u.prenom,u.sexe,u.role) !=EOF)
{
if (strcmp(u.id,id)==0){
fprintf(g,"%s %s %s %s %s\n",u.nom,u.prenom,u.sexe,u.role);
strcpy(u.id,u.id);
strcpy(u.nom
*/




int exist_id(char* id){
FILE*f=NULL;
utilisateur u;
f=fopen("utilisateur.txt","r"); 
while(fscanf(f,"%s %s %s %s %s\n",u.nom,u.prenom,u.sexe,u.id,u.role)!=EOF){
if(strcmp(u.id,id)==0)
return 1;   
}
fclose(f);
return 0;


}
void afficher_utilisateur_chercher(GtkWidget *liste)
{
      GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char nom[30];
char prenom[30];
char sexe[30];
char id[30];
char role[30];

store=NULL;

FILE *f;
 
store=gtk_tree_view_get_model(liste);

if(store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("nom", renderer,"text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("prenom", renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("sexe", renderer,"text",SEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("id", renderer,"text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("role", renderer,"text",ROLE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("utilisateurcher.txt","r");
if(f==NULL)
{
return;
}
else
{
f=fopen("utilisateurcher.txt","a+");
while(fscanf(f,"%s %s %s %s %s\n",nom,prenom,sexe,id,role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter ,NOM,nom,PRENOM,prenom,SEXE,sexe,ID,id,ROLE,role,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);

}
}
void panne_debit()
{
int capteur1=0;
int capteur2=0;
int capteur3=0;
panne p;
FILE *f, *g;
f=fopen("debit.txt","r");
g=fopen("etage.txt","w");
if(f==NULL || g==NULL)
{
return;
}
else
{
	while(fscanf(f,"%d %d %d %f \n",&p.jour,&p.heure,&p.numcapteurd,&p.valeurdebit)!=EOF)
{   
if ((p.valeurdebit<0) || (p.valeurdebit>30))
{
if(p.numcapteurd==1)
capteur1++;
if(p.numcapteurd==2)
capteur2++;
if(p.numcapteurd==3)
capteur3++;

}
}
if(capteur1>0)	
fprintf(g,"1 \n");
if(capteur2>0)	
fprintf(g,"2 \n");
if(capteur3>0)	
fprintf(g,"3 \n");
}
//fprintf(g,"%d %d %d %d\n",panne.jour,panne.heure,panne.numcapteurd,panne.valeurdebit);
fclose(f);
fclose(g);
}
void afficher_etages (int *capteur1,int *capteur2,int *capteur3){
char capt;
FILE *g,*f;
g=fopen("etage.txt","r");
f=fopen("balkiss.txt","w");
if((g==NULL) || (f==NULL))
{
return;
}
else
{
	while(fscanf(g,"%s \n",&capt)!=EOF)
{ 
if(strcmp(capt,"1")==0)
*capteur1=1;
if(strcmp(capt,"2")==0)
*capteur2=1;
if(strcmp(capt,"3")==0)
*capteur3=1;
}
}
fprintf(f,"%d %d %d \n",capteur1,capteur2,capteur3);
fclose(g);
fclose(f);
}

int verif( char log[],char Pw[])
{
FILE *f=NULL;
int trouve=-1;
char ch1[20],ch2[20];
f=fopen("user.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s",ch1,ch2)!=EOF);
{
if((strcmp(ch1,log)==0)&&(strcmp(ch2,Pw)==0))
trouve=1;

}
fclose(f);

}
return (trouve);
}

void affichage_etages(GtkWidget *liste){
		
	GtkCellRenderer *renderer ;
	GtkTreeViewColumn *column ;
	GtkTreeIter iter ;
	GtkListStore *store ;

	FILE *f=NULL;
	int  jour, heure, num_etage;
	float valeur;
	char strJour[20];
	char strHeure[20];
	char strNum_Etage[20];

	store =gtk_tree_view_get_model(liste);
if(store == NULL )
{
renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",0,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("heure",renderer,"text",1,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

renderer = gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("num etage",renderer,"text",2,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

}
store=gtk_list_store_new(3,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("debit.txt","r");
if(f!=NULL){
while(fscanf(f,"%d %d %d %f \n",&jour, &heure, &num_etage, &valeur)!=EOF){
if((valeur>30.00) ||( valeur<0)){
gtk_list_store_append(store,&iter);
sprintf(strJour,"%d",jour);
sprintf(strHeure,"%d",heure);
sprintf(strNum_Etage,"%d",num_etage);
gtk_list_store_set(store,&iter,0,strJour,1,strHeure,2,strNum_Etage,-1);
}
}
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL (store));
g_object_unref(store);
}
