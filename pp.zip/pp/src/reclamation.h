#include <gtk/gtk.h>

typedef struct
{
int jour;
int mois;
int annee;
}Datee;
typedef struct 
{ 
char id[50];
char msg[1000];
Datee datee;
char type[100];
char etat[100];
} reclamation;

void ajouter_reclamation(reclamation r);
void afficher_reclamation(GtkWidget *liste);

void modifier_reclamation1(reclamation r);
reclamation chercher_reclamation(char id[10]);
void afficher_recherche(GtkWidget *liste);
void afficher_chercher_reclamation(GtkWidget *liste);
/*int exist_id(char* id);*/
void supprimer_reclamation(reclamation r);
void modifier_reclamation(reclamation R, char id2[20]);
int service_plus_reclamer();







