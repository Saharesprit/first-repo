#include <gtk/gtk.h>


void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_quitter4_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter2_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                       gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data); 

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);



void
on_button_captd_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_stock_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_admin_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_poisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_Fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_legume_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_boisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_poulet_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_viande_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_ajouter_stock_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_poulet_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_boisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_Poisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_Fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_legume_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_viande_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview_stock_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_afficher_stock_activate      (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_stock_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
void
on_button_actualiser_stock_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_stock_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_stock_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_legume_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_fruit_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif_stock_boisson_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_poulet_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_poisson_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_viande_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_modifier_stock_clicked       (GtkButton       *button,
                                        gpointer         user_data);
/////////////////////cap//////////////
void
on_checkbutton1_cap_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_buttonOk_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonAnnuler_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_cap_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_rech_cap1_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_aff_cap1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_md_cap_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_spp_cap1_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_alarmei_cap_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_ann_suup__cap_activate              (GtkButton       *button,
                                        gpointer         user_data);

void
on_cnf_spp_cap_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_checkbutton2_cap_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_moddd_cap_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_ann_md5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_mouvement_cap_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_tmp_cap_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_debit_cap_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_fumee_cap_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ret_tach2_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_cap_alarments_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_aj_cap1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_tech_m_clicked               (GtkButton       *button,
                                        gpointer         user_data);
////////////////foyer//////////////////////
void
on_radiobutton3_e_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_e_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttonindiv_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttondouble_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbuttontriiple_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_ajouter_e_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button95_afficher_e_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button63_rechercher_e_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_supp_e_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button88_actualiser_e_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

/*void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/

void
on_buttonmodif_e_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1_trouver_e_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_foyer_m_clicked              (GtkButton       *button,
                                        gpointer         user_data);
////////////////////////////rec/////////////////////////////////

void
on_hebergement_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_urgente_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_non_urgente_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_restauration_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_find_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview_etudiant_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_admin_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_service_reclame_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_deconnecter_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rec_m_clicked                (GtkButton       *objet,
                                        gpointer         user_data);

/*void
on_button_etudiant_rec_clicked         (GtkButton       *objet,
                                        gpointer         user_data);*/

void
on_button_admin_rec_clicked            (GtkButton       *objet,
                                        gpointer         user_data);

void
on_Dec_rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_etudiant_rec_clicked         (GtkButton       *objet,
                                        gpointer         user_data);
///////////////////nutrition//////////////////////
void
on_treeview1_nutrition_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_add_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_btn_afficher_add_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview_mf_nutrition_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttn_nom_modify_nutrition_clicked  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_btn_modify_id_nutrition_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttn_date_modify_nutrition_clicked (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_dechets_modify_nutrition_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_temp_modify_nutrition_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_btn_modify_nutrition_clicked        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_recherche_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_show_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_best_menu_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_exit_nutrition_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_student_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_admin_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_Login_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_btn_exit_std_nutrition_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rech_std_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview2_nutrition_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_nut_menu_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

//void
//on_etudiant_nutrition_clicked          (GtkWidget       *objet,
                                        //gpointer         user_data);


void
on_checkbutton1_nutrition_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeviewpanned_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonpanned_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_fermer_cap_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retou_stock_clicked          (GtkButton       *button,
                                        gpointer         user_data);
