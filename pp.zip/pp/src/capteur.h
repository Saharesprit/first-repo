#include <gtk/gtk.h>

typedef struct{
int jour;
int mois;
int annee;
}Date;

typedef struct capteur capteur ;
struct capteur{
char reference[30];
char type[30];
char heure[30];
int valeur;
int etage;
Date dt;
};
void ajouter_capteur(capteur c);
void afficher_capteur(GtkWidget *liste );
void rechercher_capteur(GtkWidget *liste , char ch[]);
void supprimer_capteur (char id[]);
void modifier_capteur(char id[],capteur r);
void afficher_alarment(GtkWidget *liste,char typee[],int min,int max );



