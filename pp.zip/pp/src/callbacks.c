#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "utilisateur.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "stock.h"
#include "capteur.h"
#include "fonction.h"
#include "reclamation.h"
#include "nutritioniste.h"

int TT[2]={0,0};
int XX=0;
int YY=0;
char id111[20];
reclamation F;

typedef struct
{
char nom [20];
char prenom [20];
char cin[20];
char id[20];
char sexe [20];
char etage[20];
char type[20];
}etudiant;
int m,n;
etudiant e;

int x,y;

void
on_button1_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_authentification ;
GtkWidget *window_menu;

window_authentification=lookup_widget(objet,"window_authentification");
gtk_widget_destroy(window_authentification);


window_menu = create_window_menu ();
gtk_widget_show (window_menu);
}

void on_button3_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
utilisateur u;
char msg[50];
GtkWidget *input11;
GtkWidget *nonexiste;
GtkWidget *treeview2;
input11=lookup_widget(objet,"entry_id_chercher");
nonexiste=lookup_widget(objet,"label22");


strcpy(u.id,gtk_entry_get_text(GTK_ENTRY(input11)));
rechercher_utilisateur(u);
if (exist_id_e(u.id)==0)
{ strcpy(msg,"ID non existant");
    gtk_label_set_text(GTK_LABEL(nonexiste),msg);
}
else 
{
    strcpy(msg,"ID existant");
    gtk_label_set_text(GTK_LABEL(nonexiste),msg);
}

rechercher_utilisateur(u);

gtk_entry_set_text(GTK_ENTRY(input11),"");
treeview2=lookup_widget(objet,"treeview2");
afficher_utilisateur_chercher(treeview2); 
}


void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{


}


void
on_button_actualiser_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_principale,*w1;
GtkWidget *treeview2;

w1=lookup_widget(objet,"Principale");
window_principale=create_window_principale();

gtk_widget_show(window_principale);

gtk_widget_hide(w1);
treeview2=lookup_widget(objet,"treeview2");
//treeview2=lookup_widget(window_principale,"treeview2");
//vider(treeview2);
afficher_utilisateur(treeview2);
}


void
on_button_ajouter_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
utilisateur u;
char role[100];
GtkWidget *combobox1;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*success;
GtkWidget *window_principale;
combobox1=lookup_widget (objet, "comboboxentry1");

window_principale=lookup_widget(objet,"Principale");

input1=lookup_widget (objet, "entry_nom");
input2=lookup_widget (objet, "entry_prenom");
input3=lookup_widget (objet, "entry_id");
input5=lookup_widget (objet, "radiobutton_femme");
input6=lookup_widget (objet, "radiobutton_homme");

 if (strcmp("Agent_foyer",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(role,"Agentfoyer");
else if (strcmp("Agent_stock",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(role,"Agentstock");
else if (strcmp("Agent_reclamation",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(role,"Agentreclamation");
else if (strcmp("Nutritionniste",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(role,"Nutritionniste");
else if (strcmp("Administrateur",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(role,"Administrateur");
else
strcpy(role,"Technicien");
strcpy(u.role,role);
strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(u.id, gtk_entry_get_text(GTK_ENTRY(input3)));

if (x==4)
{
strcpy(u.sexe,"Femme");
}
if (x==3)
{
strcpy(u.sexe,"Homme");
}


//gtk_label_set_text(GTK_LABEL(success),"Ajout réuissite");

ajouter_utilisateur(u);
}


void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=3;
}


void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=4;
}


void
on_button_quitter4_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_principale;

window_principale=create_window_authentification ();
gtk_widget_show(window_principale);
}


void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=1;
}


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=2;
}


void
on_button_afficher_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_principale;
GtkWidget *treeview2;

window_principale=lookup_widget(objet,"Principale");

//window_principale=create_window_principale();

//gtk_widget_show(window_principale);

//treeview2=lookup_widget(window_principale,"treeview2");
treeview2=lookup_widget(objet,"treeview2");
afficher_utilisateur(treeview2);
}


void
on_button_quitter_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_principale;

window_principale=create_window_authentification ();
gtk_widget_show(window_principale);
}


void
on_button_quitter2_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_principale;

window_principale=create_window_authentification ();
gtk_widget_show(window_principale);
}


void
on_button_modifier_clicked             (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
utilisateur u ;
GtkWidget *input1, *input2,*input3,*input4,*output;
input1=lookup_widget (objet_graphique, "entryid_u");
input2 = lookup_widget (objet_graphique, "entrynom_u");
input3 = lookup_widget (objet_graphique, "entryprenom_u");
input4=lookup_widget(objet_graphique,"comboboxentry2_u");
if (y==1){
strcpy(u.sexe,"femme");
}
if(y==2){
strcpy(u.sexe,"homme");
}
strcpy(u.prenom, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(u.id, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(u.nom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(u.role,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input4)));
modifier_utilisateur(u);
output=lookup_widget(objet_graphique,"labelmodif_u");
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés");
}
void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* nom[20];
	gchar* prenom[20] ;
	gchar* sexe[20];
	gchar* id[20];
	gchar* role[20];
	utilisateur u;


GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model, &iter, path)) {
gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, nom,1,prenom,2,sexe,3,id,4,role,-1);
strcpy(u.nom,nom);
strcpy(u.prenom,prenom);
strcpy(u.id,id);
strcpy(u.sexe,sexe);
strcpy(u.role,role);
afficher_utilisateur(treeview);
//afficher_recherche(treeview);
}
}


void
on_button_supprimer_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
utilisateur s;
char id1[20],id2[20];
char n1[20] , n2[20],n3[20] ,n4[20];
char msg [50];
int trouve=0;
FILE *f,*E ;
input1= lookup_widget (objet, "entry_supprimer");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(input1)));
f=fopen("utilisateur.txt","r");
E=fopen("utilisateurtemp.txt","w");
  while (fscanf (f, "%s %s %s %s %s ", &n1,&n2,&n3,&id2,&n4) == 5)
    if (strcmp (id2, id1) != 0)
      fprintf (E, "%s %s %s %s %s \n", n1,n2,n3,id2,n4);
  fclose(f);
  fclose(E);
f=fopen("utilisateur.txt","w");
E=fopen("utilisateurtemp.txt","r");
  while (fscanf (E, "%s %s %s %s %s ", &n1,&n2, &n3,&id2,&n4) == 5)
      fprintf (f, "%s %s %s %s %s \n", n1,n2, n3,id2,n4);
 fclose (f);
 fclose(E);
}


void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=1;
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=2;
}




void
on_button_captd_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
int capt1=0;
int capt2=0;
int capt3=0;
  GtkWidget *labelcaptd2;
  GtkWidget *labelcaptd3;
  GtkWidget *label_captd1;
  GtkWidget *window_principale;
window_principale=lookup_widget (objet_graphique, "window_principale");
labelcaptd2=lookup_widget (objet_graphique, "labelcaptd2");
labelcaptd3=lookup_widget (objet_graphique, "labelcaptd3");
label_captd1=lookup_widget (objet_graphique, "label_captd1");

panne_debit();
/*
afficher_etages (&capt1,&capt2,&capt3);
if(capt1==1)
gtk_label_set_text(GTK_LABEL(label_captd1),"Etage1");
if(capt2==2)
gtk_label_set_text(GTK_LABEL(labelcaptd2),"Etage2");
if(capt3==3)
gtk_label_set_text(GTK_LABEL(labelcaptd3),"Etage3");*/
char capt;
FILE *g,*f;
g=fopen("etage.txt","r");
if((g==NULL))
{
return;
}
else
{
	while(fscanf(g,"%s \n",&capt)!=EOF)
{ 
if(strcmp(capt,"1 ")==0)
capt1=1;
if(strcmp(capt,"2 ")==0)
capt2=1;
if(strcmp(capt,"3 ")==0)
capt3=1;
}
}
fclose(g);
if(capt1==1)
gtk_label_set_text(GTK_LABEL(label_captd1),"Etage1");
else 
gtk_label_set_text(GTK_LABEL(label_captd1),"NOT FOUND");
if(capt2==2)
gtk_label_set_text(GTK_LABEL(labelcaptd2),"Etage2");
else 
gtk_label_set_text(GTK_LABEL(label_captd1),"NOT FOUND");
if(capt3==3)
gtk_label_set_text(GTK_LABEL(labelcaptd3),"Etage3");
else 
gtk_label_set_text(GTK_LABEL(label_captd1),"NOT FOUND");
}


void
on_button_stock_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_stock ;
GtkWidget *window_menu;

window_menu=lookup_widget(objet,"Menu");
gtk_widget_destroy(window_menu);

fenetre_stock = create_fenetre_stock ();
gtk_widget_show (fenetre_stock);
}


void
on_button_admin_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_principale ;
GtkWidget *window_men;

window_men=lookup_widget(objet,"window_menu");
gtk_widget_destroy(window_men);

window_principale = create_window_principale  ();
gtk_widget_show (window_principale );
}

///////////////////////////////aziz/////////////////////////////////////////////
void
on_button_ajouter_stock_clicked        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *categorie;
GtkWidget *id;
GtkWidget *quantitee;
GtkWidget *viande;
GtkWidget *poisson;
GtkWidget *poulet;
GtkWidget *fruit;
GtkWidget *legume;
GtkWidget *input;
GtkWidget *input1;
stock s;
input=lookup_widget (objet, "entry_Id_stock");
quantitee=lookup_widget(objet,"spinbutton_quantitee_stock");
viande=lookup_widget(objet,"radiobutton_viande");
poulet=lookup_widget(objet,"radiobutton_poulet");
poisson=lookup_widget(objet,"radiobutton_Poisson");
fruit=lookup_widget(objet,"radiobutton_Fruit");
legume=lookup_widget(objet,"radiobutton_legume");
input1=lookup_widget(objet,"comboboxentry_ajout_stock");
if(z==1)
{
strcpy(s.categorie,"viande");
}
if(z==2)
{
strcpy(s.categorie,"poulet");
}
if(z==3)
{
strcpy(s.categorie,"poisson");
}
if(z==4)
{
strcpy(s.categorie,"fruit");
}
if(z==5)
{
strcpy(s.categorie,"legume");
}
if(z==6)
{
strcpy(s.categorie,"Boisson");
}
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(s.id, gtk_entry_get_text(GTK_ENTRY(input)));
s.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(quantitee));


Ajouter_stock(s);

}


void
on_radiobutton_poulet_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
z=2;
}


void
on_radiobutton_boisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
z=6;
}


void
on_radiobutton_Poisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
z=3;
}


void
on_radiobutton_Fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
z=4;
}


void
on_radiobutton_legume_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
z=5;
}


void
on_radiobutton_viande_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
z=1;
}




void
on_button_afficher_stock_activate      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_stock,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet,"fenetre_stock");
fenetre_stock=create_fenetre_stock();

gtk_widget_show(fenetre_stock);

gtk_widget_hide(w1);

treeview1=lookup_widget(fenetre_stock,"treeview_stock");

afficher_stock(treeview1);
}


void
on_treeview_stock_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *categorie;
gchar *id;
gint *quantite;
stock s;


 GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&categorie,1,&id,2,&quantite,-1);
strcpy(s.categorie,categorie);
strcpy(s.id,id);
s.quantite=quantite;
Supprimer_stock(s);
afficher_stock(treeview);
}}
void
on_button_actualiser_stock_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_stock,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet,"fenetre_stock");
fenetre_stock=create_fenetre_stock();

gtk_widget_show(fenetre_stock);

gtk_widget_hide(w1);

treeview1=lookup_widget(fenetre_stock,"treeview_stock");

afficher_stock(treeview1);
}


void
on_button_supprimer_stock_clicked      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
stock s;
char id1[20],id2[20];
char n1[20] , n2[20];
int n3;
char msg [50];
int trouve=0;
FILE *f,*E ;
input1= lookup_widget (objet, "entry_supprimer_stock");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(input1)));
f=fopen("stock.txt","r");
E=fopen("stocktemp.txt","w");
  while (fscanf (f, "%s %s %s %d ", &n1,&n2,&id2, &n3) == 4)
    if (strcmp (id2, id1) != 0)
      fprintf (E, "%s %s %s %d \n", n1,id2,n2, n3);
  fclose(f);
  fclose(E);
f=fopen("stock.txt","w");
E=fopen("stocktemp.txt","r");
  while (fscanf (E, "%s %s %s %d ", &n1,&n2,&id2, &n3) == 4)
      fprintf (f, "%s %s %s %d \n", n1,n2,id2, n3);
 fclose (f);
 fclose(E);
}


void
on_button_chercher_stock_clicked       (GtkButton       *objet,
                                        gpointer         user_data)
{
stock s;
GtkWidget *input11;
GtkWidget *nonexiste;

input11=lookup_widget(objet,"entry_chercher_stock");
nonexiste=lookup_widget(objet,"label_chercher");


strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(input11)));

if (exist_id_stock(s.id)==0)
{ 
    gtk_label_set_text(GTK_LABEL(nonexiste),"Produit en rupture");
}
else 
{
    gtk_label_set_text(GTK_LABEL(nonexiste),"ID existant");
}

chercher_stock(s);
 


gtk_entry_set_text(GTK_ENTRY(input11),"");
GtkWidget *treeview1;
treeview1=lookup_widget(objet,"treeview_stock");
afficher_stock_chercher(treeview1);
}
void
on_radiobutton1_legume_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
A=5;
}


void
on_radiobutton1_fruit_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
A=4;
}


void
on_radiobutton_modif_stock_boisson_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
A=6;
}


void
on_radiobutton1_poulet_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
A=2;
}


void
on_radiobutton1_poisson_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
A=3;
}


void
on_radiobutton1_viande_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
A=1;
}
void
on_button_modifier_stock_clicked       (GtkButton       *objet,
                                        gpointer         user_data)
{
stock s;


GtkWidget *input,*success,*input1,*input2;
input=lookup_widget(objet,"entry_modif_id_stock");
input1=lookup_widget(objet,"spinbutton1_quantite_stock");
success=lookup_widget(objet,"label_modifier_msg");
input2=lookup_widget(objet,"comboboxentry_modifier_stock");

strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(input)));

if (A==1)
{
strcpy(s.categorie,"viande");
}
if (A==2)
{
strcpy(s.categorie,"poulet");
}
if (A==3)
{
strcpy(s.categorie,"poisson");
}
if (A==4)
{
strcpy(s.categorie,"fruit");
}
if (A==5)
{
strcpy(s.categorie,"legume");
}
if (A==6)
{
strcpy(s.categorie,"Boisson");
}
s.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));
gtk_label_set_text(GTK_LABEL(success),"Modification réuissite"); 

modifier_stock(s);
}


///////////////////////////cap////////////////////////////////////
#include "callbacks.h"
#include "interface.h"
char refff[20];
char typee[20]="temperature";
int cnf;
int cnf1;

void
on_checkbutton1_cap_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
cnf=1;
}


void
on_buttonOk_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
capteur c;

GtkWidget *entryreference ,*entryType ,*entryheure ,*etage  ,*valeur;
GtkWidget *fenetre_ajouter;
fenetre_ajouter=lookup_widget(button,"ajouter_cap");

GtkWidget *date;
date = lookup_widget (button ,"calendar1_cap");
entryreference=lookup_widget(button,"ref_cap");
entryType=lookup_widget(button,"comboboxentry1_cap");
entryheure=lookup_widget(button,"heure_cap");

etage=lookup_widget(button,"spinbutton1_cap");
valeur=lookup_widget(button,"spinbutton2_cap");

GtkWidget *e_re_cap,*e_type_cap,*e_hr_cap,*e_conf_cap;


int o=0;

e_re_cap=lookup_widget(button,"e_ref_cap");
e_type_cap=lookup_widget(button,"e_type_cap");
e_hr_cap=lookup_widget(button,"e_hr_cap");
e_conf_cap=lookup_widget(button,"e_cnf_cap");



 strcpy(c.reference,gtk_entry_get_text(GTK_ENTRY(entryreference) ) );
 strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryType)));
 strcpy(c.heure,gtk_entry_get_text(GTK_ENTRY(entryheure) ) );

 c.etage=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(etage));
 c.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeur));

gtk_calendar_get_date (GTK_CALENDAR(date),
                       &c.dt.annee,
                       &c.dt.mois,
                       &c.dt.jour);
c.dt.mois=c.dt.mois+1;

if (strcmp(c.reference,"")==0)
{o=1;
gtk_widget_show(e_re_cap);
}
else 
{o=0;
gtk_widget_hide(e_re_cap);
}

if (strcmp(c.type,"")==0)
{o=1;
gtk_widget_show(e_type_cap);
}
else 
{o=0;
gtk_widget_hide(e_type_cap);
}

if (strcmp(c.heure,"")==0)
{o=1;
gtk_widget_show(e_hr_cap);
}
else 
{o=0;
gtk_widget_hide(e_hr_cap);
}

if (cnf==0)
{
gtk_widget_show(e_conf_cap);
}
else 
{
gtk_widget_hide(e_conf_cap);
}


if (o==0 && cnf==1){

ajouter_capteur(c);
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"ajouter_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap=create_affichier_cap();
gtk_widget_show(afficher_cap);
cnf=0;
}
}


void
on_buttonAnnuler_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"ajouter_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_affichier_cap ();
  gtk_widget_show (afficher_cap);
}


void
on_treeview1_cap_row_activated         (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* ref;
	gchar* type;
	gchar* hr;
	gchar* etage;
	gchar* valeur;
	gchar* date;
	
	

	GtkTreeModel *model =gtk_tree_view_get_model(treeview);

	if (gtk_tree_model_get_iter(model, &iter , path))
	{ 
	  gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0 , &ref, 1, &type,2,&hr,3,&etage,4,&valeur,5,&date,-1);
	strcpy(refff,ref);
	
	}
}


void
on_rech_cap1_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *cherch;
char ch[20];
GtkWidget *treeview1_cap;
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"afficher_cap");

treeview1_cap=lookup_widget(afficher_cap,"treeview1_cap");
cherch = lookup_widget (button ,"entre_rech_cap");
strcpy(ch, gtk_entry_get_text(GTK_ENTRY(cherch)));
 rechercher_capteur(treeview1_cap,ch);
}


void
on_aff_cap1_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1_cap;
GtkWidget *affichier_cap;
affichier_cap=lookup_widget(button,"affichier_cap");
treeview1_cap=lookup_widget(affichier_cap,"treeview1_cap");
afficher_capteur(treeview1_cap);
}


void
on_md_cap_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"affichier_cap");
gtk_widget_destroy(afficher_cap);
GtkWidget *modifeir_cap;
modifeir_cap = create_modifier_cap ();
  gtk_widget_show (modifeir_cap);


char ref[30];
char type[30];
char hr[30];
char etage[30];
char valeur[30];
char jj[30];
char mm[30];
char aa[30];
char y[30]="";

FILE *f;

f=fopen("fichier.txt","r");







while(fscanf(f, "%s %s %s %s %s %s %s %s \n",ref,type,hr,etage,valeur,jj,mm,aa)!=EOF){
 if (strcmp(refff,ref)==0){
                gtk_entry_set_text(GTK_ENTRY(lookup_widget(modifeir_cap,"heure_cap1")),hr);
                
        

}}
}


void
on_spp_cap1_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"aff_cap1");

GtkWidget *supprimer_cap;
supprimer_cap = create_suprimer_cap ();
  gtk_widget_show (supprimer_cap);
}


void
on_alarmei_cap_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"aff_cap1");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_tache2_cap ();
  gtk_widget_show (afficher_cap);
}


void
on_ann_suup__cap_activate              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"supprimer_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;

  gtk_widget_show (afficher_cap);

}


void
on_cnf_spp_cap_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
supprimer_capteur(refff);
GtkWidget *supprimer_cap;
supprimer_cap=lookup_widget(button,"supprimer_cap");
gtk_widget_destroy(supprimer_cap);
GtkWidget *afficher_cap;

  gtk_widget_show (afficher_cap);
}


void
on_checkbutton2_cap_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
cnf1=1;
}


void
on_moddd_cap_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
capteur c;

GtkWidget *entryreference ,*entryType ,*entryheure ,*etage  ,*valeur;
GtkWidget *fenetre_ajouter;


GtkWidget *date;

entryType=lookup_widget(button,"comboboxentry2_cap");
entryheure=lookup_widget(button,"heure_cap1");
valeur=lookup_widget(button,"spinbutton3_cap");

GtkWidget *e_re_cap,*e_type_cap,*e_hr_cap,*e_conf_cap;


int o=0;

e_conf_cap=lookup_widget(button,"e_cnf_cap1");
e_type_cap=lookup_widget(button,"e_type_cap1");
e_hr_cap=lookup_widget(button,"e_hr_cap1");


 strcpy(c.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(entryType)));
 strcpy(c.heure,gtk_entry_get_text(GTK_ENTRY(entryheure) ) );

 c.valeur=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(valeur));




if (strcmp(c.type,"")==0)
{o=1;
gtk_widget_show(e_type_cap);
}
else 
{o=0;
gtk_widget_hide(e_type_cap);
}

if (strcmp(c.heure,"")==0)
{o=1;
gtk_widget_show(e_hr_cap);
}
else 
{o=0;
gtk_widget_hide(e_hr_cap);
}

if (cnf1==0)
{
gtk_widget_show(e_conf_cap);
}
else 
{
gtk_widget_hide(e_conf_cap);
}

if (o==0 && cnf1==1){


modifier_capteur(refff,c);
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"modifier_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_affichier_cap ();
  gtk_widget_show (afficher_cap);
cnf1=0;

}
}


void
on_ann_md5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"modifier_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_affichier_cap ();
 gtk_widget_show (afficher_cap);
}


void
on_mouvement_cap_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(typee,"mouvement");
}


void
on_tmp_cap_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
strcpy(typee,"temperature");
}


void
on_debit_cap_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(typee,"debit");
}


void
on_fumee_cap_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
strcpy(typee,"fumee");
}


void
on_ret_tach2_clicked                   (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajouter_cap;
ajouter_cap=lookup_widget(button,"tache2_cap");
gtk_widget_destroy(ajouter_cap);
GtkWidget *afficher_cap;
afficher_cap = create_affichier_cap ();
  gtk_widget_show (afficher_cap);
}


void
on_cap_alarments_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *min;
GtkWidget *max;
min=lookup_widget(button,"spinbutton1_min");
max=lookup_widget(button,"spinbutton2_max");

int min1;
min1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min));
int max1;
max1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(max));

GtkWidget *treeview2_cap;
GtkWidget *tache2_cap;
tache2_cap=lookup_widget(button,"tache2_cap");
treeview2_cap=lookup_widget(tache2_cap,"treeview2_cap");
afficher_alarment(treeview2_cap,typee,min1,max1);
}

void
on_aj_cap1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_cap;
afficher_cap=lookup_widget(button,"affichier_cap");
gtk_widget_destroy(afficher_cap);
GtkWidget *ajouter_cap;
ajouter_cap = create_ajouter_cap ();
  gtk_widget_show (ajouter_cap);
}


void
on_button_tech_m_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *afficher_cap;
GtkWidget *window_menu;

window_menu=lookup_widget(button,"window_menu");
gtk_widget_destroy(window_menu);

afficher_cap = create_affichier_cap ();
gtk_widget_show(afficher_cap);
}

////////////////////////////////foyer////////////////////////////////
void
on_radiobutton3_e_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{m=1;}
}


void
on_radiobutton4_e_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{m=2;}
}


void
on_checkbuttonindiv_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{n=1 ;}
}


void
on_checkbuttondouble_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{n=2 ;}
}


void
on_checkbuttontriiple_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{n=3 ;}
}


void
on_button1_ajouter_e_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char x[30];
etudiant e;
GtkWidget *input1, *input2,*input3,*input4,*input5;
input1=lookup_widget (objet_graphique, "entry51_nom_e");
input2 = lookup_widget (objet_graphique, "entry51_prenom_e");
input3 = lookup_widget (objet_graphique, "entry53_cin_e");
input4 = lookup_widget (objet_graphique, "entry2_id_e");
input5=lookup_widget(objet_graphique,"combobox2_e");
if (m==1){
strcpy(e.sexe,"femme");
}
if (m==2){
strcpy(e.sexe,"homme");
}

if (n==1){
strcpy(e.type,"Individuelle");
}
else
if (n==2){
strcpy(e.type,"Double");
}
else {
strcpy(e.type,"Triple");
}
strcpy(e.prenom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.cin, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.id, gtk_entry_get_text(GTK_ENTRY(input4)));
/*sortie2=lookup_widget(objet_graphique, "label97_videchamp");
if (veriff(x)==0)
{gtk_label_set_text(GTK_LABEL(sortie2),"champs obligatoire!");}*/
strcpy(e.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
ajouter_etudiant (e);
}


void
on_button95_afficher_e_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeview55;
//fenetre_ajout=lookup_widget(objet_graphique,"Foyer");
fenetre_afficher=lookup_widget(objet_graphique,"Foyer");

treeview55=lookup_widget(fenetre_afficher,"treeview55");
afficher_etudiants(treeview55);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter ;
gchar* nom ;
gchar* prenom ;
gchar* cin ;
gchar* id ;
gchar* sexe ;
gchar* etage ;
gchar* type ;
etudiant e ;


GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter, path))
{
	gtk_tree_model_get (GTK_LIST_STORE (model), &iter , 0 , &nom ,  1 ,&prenom, 2 , &cin , 3 , &id ,4 ,&sexe, 5 , &etage, 6 , &type,  -1);
	strcpy(e.nom,nom);
	strcpy(e.prenom,prenom);
	strcpy(e.cin,id);
	strcpy(e.id,cin);
	strcpy(e.sexe,sexe);
	strcpy(e.etage,etage);
	strcpy(e.type,type);
	afficher_etudiants(treeview);
}

}


void
on_button63_rechercher_e_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *input11;
GtkWidget *nonexiste;

input11=lookup_widget(objet_graphique,"entry20_rech_e");
nonexiste=lookup_widget(objet_graphique,"label81_rech");


strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input11)));

if (exist_id_e(e.id)==0)
{
    gtk_label_set_text(GTK_LABEL(nonexiste),"l'etudiant n'existe pas, veuillez vérifier.");
}
else

{
    gtk_label_set_text(GTK_LABEL(nonexiste),"L'etudiant existe, vous pouvez continuer.");
}

chercher_etudiant(e);
gtk_entry_set_text(GTK_ENTRY(input11),"");
GtkWidget *treeview55;
treeview55=lookup_widget(objet_graphique,"treeview55");
afficher_etudiant_chercher(treeview55);
}


void
on_button13_supp_e_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char id[20];
int k=0;
GtkWidget *window1 ,*input1;
GtkWidget *output;
etudiant e;
input1=lookup_widget(objet_graphique,"entry166_supp_e");
strcpy(e.id,gtk_entry_get_text(GTK_ENTRY(input1)));
output=lookup_widget(objet_graphique,"label83_supp");
k=exist_id_e(e.id);
if (k==0)
{
gtk_label_set_text(GTK_LABEL(output),"L'etudiant n'existe pas , veuillez verifier");
}
else
{
supprimer_etudiant (e);
gtk_label_set_text(GTK_LABEL(output),"Supprimé avec succés");
}
}


void
on_button88_actualiser_e_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Foyer,*fenetre_afficher ;
GtkWidget *treeview55 ;
Foyer=lookup_widget(objet_graphique,"Foyer");
fenetre_afficher=create_Foyer();
gtk_widget_show(fenetre_afficher);
gtk_widget_hide(Foyer);

treeview55=lookup_widget(Foyer,"treeview55");
afficher_etudiants(treeview55);
}


/*void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}
*/

void
on_buttonmodif_e_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *input1, *input2,*input3,*input4,*input5,*output;
input1=lookup_widget (objet_graphique, "entryid_e");
input2 = lookup_widget (objet_graphique, "entrynomm_e");
input3 = lookup_widget (objet_graphique, "entryprenomm_e");
input4 = lookup_widget (objet_graphique, "entrycinm_e");
input5=lookup_widget(objet_graphique,"comboboxetagem");
if (m==1){
strcpy(e.sexe,"femme");
}
else {
strcpy(e.sexe,"homme");
}

if (n==1){
strcpy(e.type,"Individuelle");
}
else
if(n==2){
strcpy(e.type,"Double");
}
else{
strcpy(e.type,"Triple");
}
strcpy(e.prenom, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.cin, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.id, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.nom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
modifier_etudiant(e);
output=lookup_widget(objet_graphique,"labelmsgg");
gtk_label_set_text(GTK_LABEL(output),"modifié avec succés");
}


void
on_button1_trouver_e_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
char etage[20];
int n ;
char msg[30];
GtkWidget *input1, *output;
input1=lookup_widget(objet_graphique,"combobox3_nbr");
strcpy(etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
n=nombre_etudiants(etage);
sprintf(msg, "%d", n);
output = lookup_widget(objet_graphique, "labelniveau");
gtk_label_set_text(GTK_LABEL(output),msg);
}


/*void
on_radiobutton3_e_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}


void
on_radiobutton4_e_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}
*/

void
on_button_foyer_m_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Foyer ;
GtkWidget *window_menu;

window_menu=lookup_widget(objet,"Menu");
gtk_widget_destroy(window_menu);

Foyer = create_Foyer ();
gtk_widget_show (Foyer);
}
///////////////////rec////////////////////////////

void
on_hebergement_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
TT[0]=1;
YY=2;
}


void
on_urgente_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
XX=1;
}


void
on_non_urgente_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
XX=2;

}


void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation r;

GtkWidget *jour,*mois,*annee,*id,*entry2,*etudiant;
GtkWidget *hebergement,*restauration,*urgente,*non_urgente,*ajout_modif, *ajout_reussi;

etudiant= lookup_widget (button, "etudiant");
jour= lookup_widget (button, "jour");
mois= lookup_widget (button, "mois");
annee= lookup_widget (button, "annee");
id= lookup_widget (button, "id");
entry2= lookup_widget (button, "entry2");
hebergement= lookup_widget (button, "hebergement");
restauration= lookup_widget (button, "restauration");
urgente= lookup_widget (button, "urgente");
non_urgente= lookup_widget (button, "non_urgente");
ajout_modif= lookup_widget (button, "ajout_modif");
ajout_reussi= lookup_widget (button, "ajout_reussi");

r.datee.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
r.datee.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));

strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(r.msg,gtk_entry_get_text(GTK_ENTRY(entry2)));

if (strcmp("2021",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
r.datee.annee=2021;
else if  (strcmp("2022",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
r.datee.annee=2022;
else if (strcmp("2023",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
r.datee.annee=2023;



if(XX==1)
{
strcpy(r.etat,"urgente");
XX=0;
}
if(XX==2)
{
strcpy(r.etat,"non_urgente");
XX=0;
}
if((TT[0]==1) && (YY==2))
{
strcpy(r.type,"hebergement");
TT[0]=0;
}
if(TT[1]==1)
{
strcpy(r.type,"restauration");
TT[1]=0;
}
if((TT[0]==1) && (YY==2) && TT[1]==1)
{
strcpy(r.type,"restauration_hebergement");
TT[0]=0;
TT[1]=0;
}

gtk_label_set_text (GTK_LABEL (ajout_reussi),"Votre reclamation a ete bien ajoutee");

ajouter_reclamation(r);
}


void
on_afficher_etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *etudiant;
GtkWidget *treeview_etudiant;

etudiant=lookup_widget(button,"etudiant");

etudiant=create_etudiant();

gtk_widget_show(etudiant);

treeview_etudiant=lookup_widget(etudiant,"treeview_etudiant");

afficher_reclamation(treeview_etudiant);
}


void
on_restauration_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
TT[1]=1;
}


void
on_button_find_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *label_id_trouve;
GtkWidget *id;
label_id_trouve= lookup_widget (button, "label_id_trouve");
id= lookup_widget (button, "id");
strcpy(id111,gtk_entry_get_text(GTK_ENTRY(id)));
F=chercher_reclamation(id111);

gtk_label_set_text (GTK_LABEL (label_id_trouve),"Réclamation trouvé !\nVous pouvez commencer la modification");
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation m;

GtkWidget *jour,*mois,*annee,*entry2,*etudiant;
GtkWidget *modif_reussi;
GtkWidget *hebergement,*restauration,*urgente,*non_urgente,*ajout_modif;
GtkWidget *treeview_etudiant;
modif_reussi= lookup_widget (button, "modif_reussi");
etudiant= lookup_widget (button, "etudiant");
jour= lookup_widget (button, "jour");
mois= lookup_widget (button, "mois");
annee= lookup_widget (button, "annee");
entry2= lookup_widget (button, "entry2");
hebergement= lookup_widget (button, "hebergement");
restauration= lookup_widget (button, "restauration");
urgente= lookup_widget (button, "urgente");
non_urgente= lookup_widget (button, "non_urgente");
ajout_modif= lookup_widget (button, "ajout_modif");
treeview_etudiant= lookup_widget (button, "treeview_etudiant");

m.datee.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
m.datee.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));

strcpy(m.msg,gtk_entry_get_text(GTK_ENTRY(entry2)));


if 
(strcmp("2021",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
m.datee.annee=2021;
else if  
(strcmp("2022",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
m.datee.annee=2022;
else
m.datee.annee=2023;

if(XX==1)
{
strcpy(m.etat,"urgente");
XX=0;
}
if(XX==2)
{
strcpy(m.etat,"non_urgente");
XX=0;
}
if((TT[0]==1) && (YY==2))
{
strcpy(m.type,"hebergement");
TT[0]=0;
}
if(TT[1]==1)
{
strcpy(m.type,"restauration");
TT[1]=0;
}
if((TT[0]==1) && (YY==2) && (TT[1]==1))
{
strcpy(m.type,"restauration_hebergement");
TT[0]=0;
TT[1]=0;
}

F.datee.jour=m.datee.jour;
F.datee.mois=m.datee.mois;
F.datee.annee=m.datee.annee;
strcpy(F.msg,m.msg);
strcpy(F.type,m.type);
strcpy(F.etat,m.etat);
strcpy(F.id,id111);
modifier_reclamation(F, id111);

afficher_reclamation(treeview_etudiant);
gtk_label_set_text (GTK_LABEL (modif_reussi),"Modification réussite");

}


void
on_treeview_etudiant_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *label_suppression_reussite;
GtkTreeIter iter;
	gchar* id;
	gchar* msg;
	gint* jour;
	gint* mois;
	gint* annee;
	gchar* type;
	gchar* etat;
	reclamation S;
	Datee d;
label_suppression_reussite= lookup_widget (treeview, "label_suppression_reussite");
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model, &iter, path)) 
	{	gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id,1,&msg,2,&jour,3,&mois,4,&annee,5,&type,6,&etat,-1);
		strcpy(S.id,id);
		strcpy(S.msg,msg);
		S.datee.jour=jour;
		S.datee.mois=mois;
		S.datee.annee=annee;
		strcpy(S.type,type);
		strcpy(S.etat,etat);
		supprimer_reclamation(S);
		afficher_reclamation(treeview);
		afficher_recherche(treeview);
		
	gtk_label_set_text (GTK_LABEL (label_suppression_reussite),"Votre réclamation a été supprimé avec succès");	
	}
}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *etudiant ;
GtkWidget *ajout_modif;

etudiant=lookup_widget(button,"etudiant");
gtk_widget_destroy(etudiant);
ajout_modif=create_ajout_modif();
gtk_widget_show(ajout_modif);
}


void
on_actualiser_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *etudiant;
GtkWidget *treeview_etudiant;

etudiant=lookup_widget(button,"etudiant");

treeview_etudiant=lookup_widget(etudiant,"treeview_etudiant");

afficher_reclamation(treeview_etudiant);
}


void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
reclamation r;
char id[20];
GtkWidget *id_chercher;
GtkWidget *etudiant;
GtkWidget *treeview_etudiant;
id_chercher=lookup_widget(button,"id_chercher");
etudiant=lookup_widget(button,"etudiant");
treeview_etudiant=lookup_widget(button,"treeview_etudiant");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(id_chercher)));
r=chercher_reclamation(id);
treeview_etudiant=lookup_widget(etudiant,"treeview_etudiant");

afficher_recherche(treeview_etudiant);
}


void
on_afficher_admin_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *admin;
GtkWidget *treeview_admin;

admin=lookup_widget(button,"admin");

admin=create_admin();

gtk_widget_show(admin);

treeview_admin=lookup_widget(admin,"treeview_admin");

afficher_reclamation(treeview_admin);
}


void
on_afficher_service_reclame_clicked    (GtkButton       *button,
                                        gpointer         user_data)
{
int service;
GtkWidget *label_service_plus_reclame,*admin;
admin=lookup_widget(button,"admin");
label_service_plus_reclame=lookup_widget(button,"label_service_plus_reclame");
service=service_plus_reclamer();

if(service==1)
{gtk_label_set_text (GTK_LABEL (label_service_plus_reclame),"Le service le plus réclamer est : Hebergement");}

else if(service==2)
{gtk_label_set_text (GTK_LABEL (label_service_plus_reclame),"Le service le plus réclamer est : Restauration");}

else if(service==3)
{gtk_label_set_text (GTK_LABEL (label_service_plus_reclame),"Les réclamations dans les deux services sont égaux");}
}


void
on_deconnecter_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *admin ;
GtkWidget *auth_rec ;

admin=lookup_widget(button,"admin");
gtk_widget_destroy(admin);
auth_rec = create_auth_rec ();
gtk_widget_show (auth_rec);
}


void
on_button_rec_m_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *auth_rec ;
GtkWidget *window_menu;

window_menu=lookup_widget(objet,"Menu");
gtk_widget_destroy(window_menu);

auth_rec = create_auth_rec ();
gtk_widget_show (auth_rec);
}


void
on_button_etudiant_rec_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *auth_re ;
GtkWidget *ajout_modi;

auth_re=lookup_widget(button,"auth_rec");
gtk_widget_destroy(auth_re);

ajout_modi=create_ajout_modif();
gtk_widget_show(ajout_modi);
}


void
on_button_admin_rec_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *auth_rec ;
GtkWidget *admin;
auth_rec=lookup_widget(objet,"auth_rec");
gtk_widget_destroy(auth_rec);
admin= create_admin();
gtk_widget_show (admin);
}


void
on_Dec_rec_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *admin ;
GtkWidget *auth_rec ;

admin=lookup_widget(button,"admin");
gtk_widget_destroy(admin);
auth_rec = create_auth_rec ();
gtk_widget_show (auth_rec);
}

/*
void
on_button_etudiant_rec_clicked         (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *auth_rec ;
GtkWidget *etudiant;

auth_rec=lookup_widget(objet,"auth_rec");
gtk_widget_destroy(auth_rec);

etudiant=create_etudiant();
gtk_widget_show(etudiant);
}*/

///////////////////nutrition////////////////////////////////////
int t_nutrition[30];
int x_nutrition=0;
int y_nutrition=0;
int z_nutrition=0;
void
on_treeview1_nutrition_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* id;
	gchar* nom_repas;
	gint* nbr_dechets;
	gchar* temps;
	gint* jour;
	gint* mois;
	gint* annee;
	menu S;
	Date_nutrition d;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model, &iter, path)) {
		gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id,1,&nom_repas,2,&jour,3,&mois,4,&annee,5,&nbr_dechets,6,&temps,-1);
		strcpy(S.id,id);
		strcpy(S.nom_repas,nom_repas);
		S.nbr_dechets=nbr_dechets;
		S.date_nutrition.jour=jour;
		S.date_nutrition.mois=mois;
		S.date_nutrition.annee=annee;
		strcpy(S.temps,temps);
		//supprimer_menu(S);
		afficher_menu_nutrition(treeview,"menu.txt");
		afficher_menu_nutrition(treeview,"find.txt");
	}
}


void
on_button_add_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
menu S;
GtkWidget *input1_nutrition, *input2_nutrition;
GtkWidget *Menu_admin_nutrition;
GtkWidget *jour_nutrition;
GtkWidget *mois_nutrition;
GtkWidget *annee_nutrition;
GtkWidget *combobox1_nutrition;

Menu_admin_nutrition=lookup_widget(objet,"Menu_admin_nutrition");
input1_nutrition=lookup_widget(objet,"id_nutrition");
input2_nutrition=lookup_widget(objet,"nom_repas_nutrition");
jour_nutrition=lookup_widget(objet, "jour_nutrition");
mois_nutrition=lookup_widget(objet, "mois_nutrition");
annee_nutrition=lookup_widget(objet, "annee_nutrition");
combobox1_nutrition=lookup_widget (objet,"combobox1_nutrition");
S.date_nutrition.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour_nutrition));
S.date_nutrition.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois_nutrition));
S.date_nutrition.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee_nutrition));
if 
(strcmp("Petit-déjeuner",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1_nutrition)))==0)
strcpy(S.temps,"Petit-déjeuner");
else if  
(strcmp("Déjeuner",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1_nutrition)))==0)
strcpy(S.temps,"Déjeuner");
else
strcpy(S.temps,"Dîner");

strcpy(S.id,gtk_entry_get_text(GTK_ENTRY(input1_nutrition)));
strcpy(S.nom_repas,gtk_entry_get_text(GTK_ENTRY(input2_nutrition)));


ajouter_menu_nutrition(S);

}


void
on_btn_afficher_add_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Menu_admin_nutrition;
GtkWidget *treeview2_nutrition;
GtkWidget *notebook1_nutrition;

Menu_admin_nutrition=lookup_widget(objet,"Menu_admin_nutrition");
treeview2_nutrition=lookup_widget(objet,"treeview2_nutrition");
notebook1_nutrition=lookup_widget(objet,"notebook1_nutrition");
afficher_menu_nutrition(treeview2_nutrition,"menu.txt");
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook1_nutrition")));
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook1_nutrition")));
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook1_nutrition")));
}


void
on_treeview_mf_nutrition_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* id;
	gchar* nom_repas;
	gint* nbr_dechets;
	gchar* temps;
	gint* jour;
	gint* mois;
	gint* annee;
	menu S;
	Date_nutrition d;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model, &iter, path)) {
		gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id,1,&nom_repas,2,&jour,3,&mois,4,&annee,5,&nbr_dechets,6,&temps,-1);
		strcpy(S.id,id);
		strcpy(S.nom_repas,nom_repas);
		S.nbr_dechets=nbr_dechets;
		S.date_nutrition.jour=jour;
		S.date_nutrition.mois=mois;
		S.date_nutrition.annee=annee;
		strcpy(S.temps,temps);
		afficher_menu_nutrition(treeview,"find.txt");
	}

}


void
on_buttn_nom_modify_nutrition_clicked  (GtkWidget       *objet,
                                        gpointer         user_data)
{
t_nutrition[0]=1;
}


void
on_btn_modify_id_nutrition_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
menu d;
char id[20];
GtkWidget *entry2_nutrition;
GtkWidget *Menu_admin_nutrition;
GtkWidget *treeview_mf_nutrition;
Menu_admin_nutrition=lookup_widget(objet,"Menu_admin_nutrition");
entry2_nutrition=lookup_widget(objet,"entry2_nutrition");
treeview_mf_nutrition=lookup_widget(objet,"treeview_mf_nutrition");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry2_nutrition)));
d=rechercher_menu_by_id_nutrition(id);
//rechercher_menu_nutrition(d);

treeview_mf_nutrition=lookup_widget(objet,"treeview_mf_nutrition");
afficher_menu_nutrition(treeview_mf_nutrition,"find.txt");
}


void
on_buttn_date_modify_nutrition_clicked (GtkWidget       *objet,
                                        gpointer         user_data)
{
t_nutrition[1]=2;
}


void
on_button_dechets_modify_nutrition_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
t_nutrition[2]=3;
z_nutrition=1;
}


void
on_button_temp_modify_nutrition_clicked
                                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
t_nutrition[3]=4;
}


void
on_btn_modify_nutrition_clicked        (GtkWidget       *objet,
                                        gpointer         user_data)
{
menu d;
menu m;
strcpy(m.id,"");
m.date_nutrition.jour=0;
m.date_nutrition.mois=0;
m.date_nutrition.annee=0;
m.nbr_dechets=0;
strcpy(m.temps,"");
char id[20];
GtkWidget *entry2_nutrition;
GtkWidget *entry3_nutrition;
GtkWidget *Menu_admin_nutrition;
GtkWidget *spinbutton_jj_nutrition;
GtkWidget *spinbutton_mm_nutrition;
GtkWidget *spinbutton_aa_nutrition;
GtkWidget *spinbutton4_nutrition;
GtkWidget *combobox_modif_temps_nutrition;
GtkWidget *notebook1_nutrition;
GtkWidget *treeview2_nutrition;
GtkWidget *treeview_mf_nutrition;
GtkWidget *label_mf_nutrition;
label_mf_nutrition=lookup_widget(objet, "label_mf_nutrition");
spinbutton_jj_nutrition=lookup_widget(objet, "spinbutton_jj_nutrition");
spinbutton_mm_nutrition=lookup_widget(objet, "spinbutton_mm_nutrition");
spinbutton_aa_nutrition=lookup_widget(objet, "spinbutton_aa_nutrition");
spinbutton4_nutrition=lookup_widget(objet, "spinbutton4_nutrition");
combobox_modif_temps_nutrition=lookup_widget(objet, "combobox_modif_temps_nutrition");
Menu_admin_nutrition=lookup_widget(objet,"Menu_admin_nutrition");
entry2_nutrition=lookup_widget(objet,"entry2_nutrition");
entry3_nutrition=lookup_widget(objet,"entry3_nutrition");
treeview_mf_nutrition=lookup_widget(objet,"treeview_mf_nutrition");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(entry2_nutrition)));
d=rechercher_menu_by_id_nutrition(id);
strcpy(m.id,id);
m.date_nutrition.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton_jj_nutrition));
m.date_nutrition.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton_mm_nutrition));
m.date_nutrition.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton_aa_nutrition));
m.nbr_dechets=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton4_nutrition));
if 
(strcmp("Petit-déjeuner",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_modif_temps_nutrition)))==0)
strcpy(m.temps,"Petit-déjeuner");
else if  
(strcmp("Déjeuner",gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox_modif_temps_nutrition)))==0)
strcpy(m.temps,"Déjeuner");
else
strcpy(m.temps,"Dîner");
strcpy(m.nom_repas,gtk_entry_get_text(GTK_ENTRY(entry3_nutrition)));
if(t_nutrition[1]==2){
d.date_nutrition.jour=m.date_nutrition.jour;
d.date_nutrition.mois=m.date_nutrition.mois;
d.date_nutrition.annee=m.date_nutrition.annee;
t_nutrition[1]=0;
}
if((t_nutrition[2]==3)||(z_nutrition==1)){
d.nbr_dechets=m.nbr_dechets;
t_nutrition[2]=0;
z_nutrition=0;
}
if(t_nutrition[3]==4){
strcpy(d.temps,m.temps);
t_nutrition[3]=0;
}
if(t_nutrition[0]==1){
strcpy(d.nom_repas,m.nom_repas);
t_nutrition[0]=0;
}

modifier_menu_nutrition(d,id);
gtk_label_set_text (GTK_LABEL (label_mf_nutrition),"Modification réussi");
d=rechercher_menu_by_id_nutrition(id);

treeview_mf_nutrition=lookup_widget(objet,"treeview_mf_nutrition");
afficher_menu_nutrition(treeview_mf_nutrition,"find.txt");
treeview2_nutrition=lookup_widget(objet,"treeview2_nutrition");
afficher_menu_nutrition(treeview2_nutrition,"menu.txt");
//gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook1_nutrition")));
//gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook1_nutrition")));
}


void
on_button_recherche_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
Date_nutrition d;
GtkWidget *Menu_admin_nutrition;
GtkWidget *jour_nutrition;
GtkWidget *mois_nutrition;
GtkWidget *annee_nutrition;
GtkWidget *treeview2_nutrition;
GtkWidget *notebook1_nutrition;

Menu_admin_nutrition=lookup_widget(objet,"Menu_admin_nutrition");
jour_nutrition=lookup_widget(objet, "spinbutton_j_nutrition");
mois_nutrition=lookup_widget(objet, "spinbutton_m_nutrition");
annee_nutrition=lookup_widget(objet,"spinbutton_a_nutrition");

d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour_nutrition));
d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois_nutrition));
d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (annee_nutrition));
rechercher_menu_nutrition(d);
//gtk_widget_destroy(Menu_admin);
//Afficher=lookup_widget(objet,"Menu_admin");
//Afficher=create_Menu_admin();

//gtk_widget_show(Afficher);
treeview2_nutrition=lookup_widget(objet,"treeview2_nutrition");
afficher_menu_nutrition(treeview2_nutrition,"find.txt");
gtk_notebook_next_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook1_nutrition")));
}



void
on_button_show_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Menu_admin_nutrition;
GtkWidget *treeview2_nutrition;

Menu_admin_nutrition=lookup_widget(objet,"Menu_admin_nutrition");
treeview2_nutrition=lookup_widget(objet,"treeview2_nutrition");
afficher_menu_nutrition(treeview2_nutrition,"menu.txt");
}


void
on_button_best_menu_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Menu_admin_nutrition;
GtkWidget *treeview2_nutrition;

Menu_admin_nutrition=lookup_widget(objet,"Menu_admin_nutrition");
meilleur_menu_de_la_semaine_nutrition();
treeview2_nutrition=lookup_widget(objet,"treeview2_nutrition");
afficher_menu_nutrition(treeview2_nutrition,"best_menu.txt");
}


void
on_button_exit_nutrition_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_student_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y_nutrition=1;}
}


void
on_admin_toggled                       (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON(togglebutton)))
{y_nutrition=2;}
}


/*void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}*/


void
on_button_Login_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *authentification_nutrition;
GtkWidget *window1_nutrition;
GtkWidget *Menu_admin_nutrition;
GtkWidget *Menu_student_nutrition;
authentification_nutrition=lookup_widget(objet,"authentification_nutrition");
window1_nutrition=lookup_widget(objet,"window1_nutrition");
Menu_student_nutrition=lookup_widget(objet,"Menu_student_nutrition");
Menu_admin_nutrition=lookup_widget(objet,"Menu_admin_nutrition");
if(x_nutrition==1){
//gtk_widget_destroy(authentification);

window1_nutrition=create_window1_nutrition();
gtk_widget_show(window1_nutrition);
x_nutrition=0;
}else{
if(y_nutrition==1){
//gtk_widget_destroy(authentification_nutrition);
Menu_student_nutrition=create_Menu_student_nutrition();
gtk_widget_show(Menu_student_nutrition);
y_nutrition=0;
}
if(y_nutrition==2){
//gtk_widget_destroy(authentification_nutrition);
Menu_admin_nutrition=create_Menu_admin_nutrition();
gtk_widget_show(Menu_admin_nutrition);
y_nutrition=0;
}
}
}


void
on_btn_exit_std_nutrition_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button_rech_std_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
Date_nutrition d;
GtkWidget *Menu_student_nutrition;
GtkWidget *spinbutton_jour_nutrition;
GtkWidget *spinbutton_mois_nutrition;
GtkWidget *spinbutton_annnee_nutrition;
GtkWidget *treeview1_nutrition;


Menu_student_nutrition=lookup_widget(objet,"Menu_student_nutrition");
spinbutton_jour_nutrition=lookup_widget(objet, "spinbutton_jour_nutrition");
spinbutton_mois_nutrition=lookup_widget(objet, "spinbutton_mois_nutrition");
spinbutton_annnee_nutrition=lookup_widget(objet, "spinbutton_annnee_nutrition");

d.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton_jour_nutrition));
d.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton_mois_nutrition));
d.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (spinbutton_annnee_nutrition));
rechercher_menu_nutrition(d);

treeview1_nutrition=lookup_widget(objet,"treeview1_nutrition");
afficher_menu_nutrition(treeview1_nutrition,"find.txt");
}


void
on_treeview2_nutrition_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* id;
	gchar* nom_repas;
	gint* nbr_dechets;
	gchar* temps;
	gint* jour;
	gint* mois;
	gint* annee;
	menu S;
	Date_nutrition d;

	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model, &iter, path)) {
		gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id,1,&nom_repas,2,&jour,3,&mois,4,&annee,5,&nbr_dechets,6,&temps,-1);
		strcpy(S.id,id);
		strcpy(S.nom_repas,nom_repas);
		S.nbr_dechets=nbr_dechets;
		S.date_nutrition.jour=jour;
		S.date_nutrition.mois=mois;
		S.date_nutrition.annee=annee;
		strcpy(S.temps,temps);
		afficher_menu_nutrition(treeview,"find.txt");
		afficher_menu_nutrition(treeview,"best_menu.txt");
		supprimer_menu_nutrition(S);
		afficher_menu_nutrition(treeview,"menu.txt");
	}
}


void
on_button_nut_menu_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *authentification_nutrition;
authentification_nutrition=lookup_widget(objet,"authentification_nutrition");
authentification_nutrition=create_authentification_nutrition();
gtk_widget_show(authentification_nutrition);
}



void
on_checkbutton1_nutrition_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
{x_nutrition=1;}
}


void
on_treeviewpanned_row_activated        (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

}


void
on_buttonpanned_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8, *window7;
	GtkWidget *treeviewpanne;
	char fichier[]={".txt"};
GtkWidget *window_principale;
GtkWidget *treeview2;

window_principale=lookup_widget(button,"Principale");

//window_principale=create_window_principale();

//gtk_widget_show(window_principale);

//treeview2=lookup_widget(window_principale,"treeview2");
treeview2=lookup_widget(button,"treeviewpanned");
affichage_etages(treeview2);
}

void
on_fermer_cap_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion;
gestion=lookup_widget(button,"affichier_cap");
gtk_widget_destroy(gestion);
GtkWidget *menu;
menu = create_window_menu ();
gtk_widget_show (menu);
}


void
on_button_retou_stock_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *gestion;
gestion=lookup_widget(button,"fenetre_stock");
gtk_widget_destroy(gestion);
GtkWidget *menu;
menu = create_window_menu ();
gtk_widget_show (menu);
}

