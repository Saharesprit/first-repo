#ifndef FONCTION_H_INCLUDED
#define FONCTION_H_INCLUDED
#endif // FONCTION_H_INCLUDED
#include <gtk/gtk.h> 
typedef struct {

	int jour;
	int heure;
	int numcapteurd;
	float valeurdebit;
}panne;

typedef struct
{
char nom[20];	
char prenom[20];
char sexe[20];
char id[20];
char role[20];
}utilisateur;
int x,y;

void afficher_utilisateur(GtkWidget *liste1);
void ajouter_utilisateur(utilisateur u);
void suprimer_utilisateur(utilisateur u);
void rechercher_utilisateur(utilisateur u);
void modifier_utilisateur(utilisateur u);
void afficher_etages (int *capteur1,int *capteur2,int *capteur3);
void afficher_utilisateur_chercher(GtkWidget *liste);
void panne_debit();
int verif( char log[],char Pw[]);
void affichage_etages(GtkWidget *liste);

