#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"


int t[2]={0,0};
int x=0;
int y=0;
char id1[20];
reclamation F;


void
on_hebergement_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
t[0]=1;
y=2;
}


void
on_restauration_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(togglebutton))
t[1]=1;
}


void
on_urgente_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=1;

}


void
on_non_urgente_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=2;

}


void
on_modifier_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{

reclamation m;

GtkWidget *jour,*mois,*annee,*entry2,*etudiant;
GtkWidget *modif_reussi;
GtkWidget *hebergement,*restauration,*urgente,*non_urgente,*ajout_modif;
GtkWidget *treeview_etudiant;
modif_reussi= lookup_widget (objet_graphique, "modif_reussi");
etudiant= lookup_widget (objet_graphique, "etudiant");
jour= lookup_widget (objet_graphique, "jour");
mois= lookup_widget (objet_graphique, "mois");
annee= lookup_widget (objet_graphique, "annee");
entry2= lookup_widget (objet_graphique, "entry2");
hebergement= lookup_widget (objet_graphique, "hebergement");
restauration= lookup_widget (objet_graphique, "restauration");
urgente= lookup_widget (objet_graphique, "urgente");
non_urgente= lookup_widget (objet_graphique, "non_urgente");
ajout_modif= lookup_widget (objet_graphique, "ajout_modif");
treeview_etudiant= lookup_widget (objet_graphique, "treeview_etudiant");

m.date.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
m.date.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));

strcpy(m.msg,gtk_entry_get_text(GTK_ENTRY(entry2)));


if 
(strcmp("2021",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
m.date.annee=2021;
else if  
(strcmp("2022",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
m.date.annee=2022;
else
m.date.annee=2023;

if(x==1)
{
strcpy(m.etat,"urgente");
x=0;
}
if(x==2)
{
strcpy(m.etat,"non_urgente");
x=0;
}
if((t[0]==1) && (y==2))
{
strcpy(m.type,"hebergement");
t[0]=0;
}
if(t[1]==1)
{
strcpy(m.type,"restauration");
t[1]=0;
}
if((t[0]==1) && (y==2) && (t[1]==1))
{
strcpy(m.type,"restauration_hebergement");
t[0]=0;
t[1]=0;
}

F.date.jour=m.date.jour;
F.date.mois=m.date.mois;
F.date.annee=m.date.annee;
strcpy(F.msg,m.msg);
strcpy(F.type,m.type);
strcpy(F.etat,m.etat);
strcpy(F.id,id1);
modifier_reclamation(F, id1);

afficher_reclamation(treeview_etudiant);
gtk_label_set_text (GTK_LABEL (modif_reussi),"Modification réussite");

}


void
on_ajouter_clicked                     (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
reclamation r;

GtkWidget *jour,*mois,*annee,*id,*entry2,*etudiant;
GtkWidget *hebergement,*restauration,*urgente,*non_urgente,*ajout_modif, *ajout_reussi;

etudiant= lookup_widget (objet_graphique, "etudiant");
jour= lookup_widget (objet_graphique, "jour");
mois= lookup_widget (objet_graphique, "mois");
annee= lookup_widget (objet_graphique, "annee");
id= lookup_widget (objet_graphique, "id");
entry2= lookup_widget (objet_graphique, "entry2");
hebergement= lookup_widget (objet_graphique, "hebergement");
restauration= lookup_widget (objet_graphique, "restauration");
urgente= lookup_widget (objet_graphique, "urgente");
non_urgente= lookup_widget (objet_graphique, "non_urgente");
ajout_modif= lookup_widget (objet_graphique, "ajout_modif");
ajout_reussi= lookup_widget (objet_graphique, "ajout_reussi");

r.date.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (jour));
r.date.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (mois));

strcpy(r.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(r.msg,gtk_entry_get_text(GTK_ENTRY(entry2)));

if (strcmp("2021",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
r.date.annee=2021;
else if  (strcmp("2022",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
r.date.annee=2022;
else if (strcmp("2023",gtk_combo_box_get_active_text(GTK_COMBO_BOX(annee)))==0)
r.date.annee=2023;



if(x==1)
{
strcpy(r.etat,"urgente");
x=0;
}
if(x==2)
{
strcpy(r.etat,"non_urgente");
x=0;
}
if((t[0]==1) && (y==2))
{
strcpy(r.type,"hebergement");
t[0]=0;
}
if(t[1]==1)
{
strcpy(r.type,"restauration");
t[1]=0;
}
if((t[0]==1) && (y==2) && t[1]==1)
{
strcpy(r.type,"restauration_hebergement");
t[0]=0;
t[1]=0;
}

gtk_label_set_text (GTK_LABEL (ajout_reussi),"Votre reclamation a ete bien ajoutee");

ajouter_reclamation(r);
}


void
on_afficher_etudiant_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *etudiant;
GtkWidget *treeview_etudiant;

etudiant=lookup_widget(objet,"etudiant");

etudiant=create_etudiant();

gtk_widget_show(etudiant);

treeview_etudiant=lookup_widget(etudiant,"treeview_etudiant");

afficher_reclamation(treeview_etudiant);
}


void
on_chercher_clicked                    (GtkButton       *objet,
                                        gpointer         user_data)
{
reclamation r;
char id[20];
GtkWidget *id_chercher;
GtkWidget *etudiant;
GtkWidget *treeview_etudiant;
id_chercher=lookup_widget(objet,"id_chercher");
etudiant=lookup_widget(objet,"etudiant");
treeview_etudiant=lookup_widget(objet,"treeview_etudiant");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(id_chercher)));
r=chercher_reclamation(id);
treeview_etudiant=lookup_widget(etudiant,"treeview_etudiant");

afficher_recherche(treeview_etudiant);
}


void
on_actualiser_clicked                  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *etudiant;
GtkWidget *treeview_etudiant;

etudiant=lookup_widget(objet,"etudiant");

treeview_etudiant=lookup_widget(etudiant,"treeview_etudiant");

afficher_reclamation(treeview_etudiant);

}


void
on_afficher_admin_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *admin;
GtkWidget *treeview_admin;

admin=lookup_widget(objet,"admin");

admin=create_admin();

gtk_widget_show(admin);

treeview_admin=lookup_widget(admin,"treeview_admin");

afficher_reclamation(treeview_admin);
}


void
on_afficher_service_reclame_clicked    (GtkButton       *objet,
                                        gpointer         user_data)
{
int service;
GtkWidget *label_service_plus_reclame,*admin;
admin=lookup_widget(objet,"admin");
label_service_plus_reclame=lookup_widget(objet,"label_service_plus_reclame");
service=service_plus_reclamer();

if(service==1)
{gtk_label_set_text (GTK_LABEL (label_service_plus_reclame),"Le service le plus réclamer est : Hebergement");}

else if(service==2)
{gtk_label_set_text (GTK_LABEL (label_service_plus_reclame),"Le service le plus réclamer est : Restauration");}

else if(service==3)
{gtk_label_set_text (GTK_LABEL (label_service_plus_reclame),"Les réclamations dans les deux services sont égaux");}

}

void
on_treeview_etudiant_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkWidget *label_suppression_reussite;
GtkTreeIter iter;
	gchar* id;
	gchar* msg;
	gint* jour;
	gint* mois;
	gint* annee;
	gchar* type;
	gchar* etat;
	reclamation S;
	Date d;
label_suppression_reussite= lookup_widget (treeview, "label_suppression_reussite");
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);

	if(gtk_tree_model_get_iter(model, &iter, path)) 
	{	gtk_tree_model_get(GTK_LIST_STORE(model), &iter, 0, &id,1,&msg,2,&jour,3,&mois,4,&annee,5,&type,6,&etat,-1);
		strcpy(S.id,id);
		strcpy(S.msg,msg);
		S.date.jour=jour;
		S.date.mois=mois;
		S.date.annee=annee;
		strcpy(S.type,type);
		strcpy(S.etat,etat);
		supprimer_reclamation(S);
		afficher_reclamation(treeview);
		afficher_recherche(treeview);
		
	gtk_label_set_text (GTK_LABEL (label_suppression_reussite),"Votre réclamation a été supprimé avec succès");	
	}
}


void
on_button_find_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *label_id_trouve;
GtkWidget *id;
label_id_trouve= lookup_widget (button, "label_id_trouve");
id= lookup_widget (button, "id");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(id)));
F=chercher_reclamation(id1);

gtk_label_set_text (GTK_LABEL (label_id_trouve),"Réclamation trouvé !\nVous pouvez commencer la modification");


}


void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *etudiant ;
GtkWidget *ajout_modif;

etudiant=lookup_widget(button,"etudiant");
gtk_widget_destroy(etudiant);
ajout_modif=create_ajout_modif();
gtk_widget_show(ajout_modif);
}


void
on_deconnecter_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *admin ;

admin=lookup_widget(button,"admin");
gtk_widget_destroy(admin);
}


void
on_disconnected_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ajout_modif ;

ajout_modif=lookup_widget(button,"ajout_modif");
gtk_widget_destroy(ajout_modif);
}

