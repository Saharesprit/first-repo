#include <gtk/gtk.h>


void
on_hebergement_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_restauration_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_urgente_toggled                     (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_non_urgente_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_afficher_etudiant_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkButton       *objet,
                                        gpointer         user_data);

void
on_afficher_admin_clicked              (GtkButton       *objet,
                                        gpointer         user_data);

void
on_afficher_service_reclame_clicked    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_treeview_etudiant_row_activated     (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_find_clicked                 (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_deconnecter_admin_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_non_urgente_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_deconnecter_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_disconnected_clicked                (GtkButton       *button,
                                        gpointer         user_data);
