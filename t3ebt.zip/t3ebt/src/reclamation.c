#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"reclamation.h"
#include <gtk/gtk.h>

enum
{
	ID,
	MSG,
	JOUR,
	MOIS,
	ANNEE,
	TYPE,
	ETAT,
	COLUMNS
};
void ajouter_reclamation(reclamation r)
{

FILE *f;
f=fopen("reclamation.txt","a+");
if(f!=NULL){
fprintf(f,"%s %s %d %d %d %s %s \n",r.id,r.msg,r.date.jour,r.date.mois,r.date.annee,r.type,r.etat);
fclose(f);
}
}

void afficher_reclamation(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char id[50];
char msg[1000];
int jour;
int mois;
int annee;
char type[20];
char etat[20];

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("msg",renderer,"text",MSG,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etat",renderer,"text",ETAT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("reclamation.txt","r");
if(f==NULL)
{
return;
}
else
{
f= fopen("reclamation.txt","a+");
while(fscanf(f,"%s %s %d %d %d %s %s \n",id,msg,&jour,&mois,&annee,type,etat)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set (store, &iter,ID,id,MSG,msg,JOUR,jour,MOIS,mois,ANNEE,annee,TYPE,type,ETAT,etat,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW (liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}

reclamation chercher_reclamation(char id[10])  
{
FILE* f;
FILE* f1;
reclamation r;
reclamation t;

f=fopen("reclamation.txt","r");
f1=fopen("chercher.txt","w");
if(f==NULL || f1==NULL)
{
return;
}
else
{
	while(fscanf(f,"%s %s %d %d %d %s %s \n",r.id,r.msg,&r.date.jour,&r.date.mois,&r.date.annee,r.type,r.etat)!=EOF)
{
if(strcmp(r.id,id)==0 ){
fprintf(f1,"%s %s %d %d %d %s %s \n",r.id,r.msg,r.date.jour,r.date.mois,r.date.annee,r.type,r.etat);
strcpy(t.id,r.id);
strcpy(t.msg,r.msg);
t.date.jour=r.date.jour;
t.date.mois=r.date.mois;
t.date.annee=r.date.annee;
strcpy(t.type,r.type);
strcpy(t.etat,r.etat);

}

}
fclose(f);
fclose(f1);
return t;
}
}
void afficher_recherche(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char id[50];
	char msg[1000];
	int jour;
	int mois;
	int annee;
	char type[20];
	char etat[20];
	store=NULL;


FILE *g;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("msg",renderer,"text",MSG,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etat",renderer,"text",ETAT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
g=fopen("chercher.txt","r");
if(g==NULL)
{
return;
}
else
{
g= fopen("chercher.txt","a+");
	while(fscanf(g,"%s %s %d %d %d %s %s \n",id,msg,&jour,&mois,&annee,type,etat)!=EOF)
{
gtk_list_store_append(store, &iter);
gtk_list_store_set (store, &iter,ID,id,MSG,msg,JOUR,jour,MOIS,mois,ANNEE,annee,TYPE,type,ETAT,etat,-1);

}
fclose(g);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
remove("chercher.txt");
}
}

void afficher_chercher_reclamation(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char id[50];
char msg[1000];
int jour;
int mois;
int annee;
char type[20];
char etat[20];


store=NULL;
	
FILE *f;

store=gtk_tree_view_get_model(liste);

if(store==NULL)
	{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("msg",renderer,"text",MSG,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("etat",renderer,"text",ETAT,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	}
store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("chercher.txt","r");

if(f==NULL)
{
return;
}
else
{
f=fopen("chercher.txt","a+");
while(fscanf(f,"%s %s %d %d %d %s %s \n",id,msg,&jour,&mois,&annee,type,etat)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set (store, &iter,ID,id,MSG,msg,JOUR,jour,MOIS,mois,ANNEE,annee,TYPE,type,ETAT,etat,-1);		
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);

}
}



void modifier_reclamation1 (reclamation r)
{
FILE *f;
FILE *t;

reclamation R ;
f=fopen("reclamation.txt","r");
t=fopen("temp.text","a");

    if (f!=NULL || t!=NULL)
    {

    while(fscanf(f,"%s %s %d %d %d %s %s \n",R.id,R.msg,&R.date.jour,&R.date.mois,&R.date.annee,R.type,R.etat)!=EOF)
    {

if(strcmp(R.id,r.id)==0)
        {
fprintf(t,"%s %s %d %d %d %s %s \n",r.id,r.msg,&r.date.jour,&r.date.mois
,&r.date.annee,r.type,r.etat);
}
else
fprintf(t,"%s %s %d %d %d %s %s \n",R.id,R.msg,&R.date.jour,&R.date.mois,&R.date.annee,R.type,R.etat);
    }
    }

fclose(t);
fclose(f);
remove("reclamation.txt");
rename("temp.text","reclamation.txt");
}


void supprimer_reclamation(reclamation r){
char id[50];
char msg[1000];
int jour;
int mois;
int annee;
char type[100];
char etat[100];
FILE *f, *g;
f=fopen("reclamation.txt","r");
g=fopen("dump.txt","w");
if(f==NULL || g==NULL)
{
return;
}
else
{
	while(fscanf(f,"%s %s %d %d %d %s %s \n",id,msg,&jour,&mois,&annee,type,etat)!=EOF)
{
if((strcmp(r.id,id)!=0)||(strcmp(r.msg,msg)!=0) || (r.date.jour!=jour) || (r.date.mois!= mois) || (r.date.annee!= annee) || (strcmp(r.type,type)!=0) ||(strcmp(r.etat,etat)!=0))
fprintf(g,"%s %s %d %d %d %s %s \n",id,msg,jour,mois,annee,type,etat);
}
fclose(f);
fclose(g);
remove("reclamation.txt");
rename("dump.txt","reclamation.txt");
}
}
void modifier_reclamation(reclamation R, char id2[20]){
	char id[50];
	char msg[1000];
	int jour;
	int mois;
	int annee;
	char type[100];
	char etat[100];

FILE *f, *g;
f=fopen("reclamation.txt","r");
g=fopen("find.txt","w");
if(f==NULL || g==NULL)
{
return;
}
else
{
	while(fscanf(f,"%s %s %d %d %d %s %s \n",id,msg,&jour,&mois,&annee,type,etat)!=EOF)
{
if(strcmp(id,id2)!=0)
fprintf(g,"%s %s %d %d %d %s %s \n",id,msg,jour,mois,annee,type,etat);
if(strcmp(id,id2)==0){

fprintf(g,"%s %s %d %d %d %s %s \n",id,R.msg,R.date.jour,R.date.mois,R.date.annee,R.type,R.etat);
}
}
fclose(f);
fclose(g);
remove("reclamation.txt");
rename("find.txt","reclamation.txt");
}
}


int service_plus_reclamer()
{
FILE* f;
reclamation r;
int hebergement=0;
int restauration=0;
int service;

f=fopen("reclamation.txt","r");
if(f==NULL)
{
return;
}
else
{
	while(fscanf(f,"%s %s %d %d %d %s %s \n",r.id,r.msg,&r.date.jour,&r.date.mois,&r.date.annee,r.type,r.etat)!=EOF)
{
if(strcmp(r.type,"hebergement")==0 ){

hebergement++;
}
if(strcmp(r.type,"restauration")==0 ){

restauration++;
}
}

if(hebergement>restauration)
{service=1;}
else if(hebergement<restauration)
{service=2;}
else if (hebergement==restauration)
{service=3;}

fclose(f);

return service;
}



}
