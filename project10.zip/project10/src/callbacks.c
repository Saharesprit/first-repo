#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "stock.h"


void
on_button_ajouter_stock_clicked        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *categorie;
GtkWidget *id;
GtkWidget *quantitee;
GtkWidget *viande;
GtkWidget *poisson;
GtkWidget *poulet;
GtkWidget *fruit;
GtkWidget *legume;
GtkWidget *input;
GtkWidget *input1;
stock s;
input=lookup_widget (objet, "entry_Id_stock");
quantitee=lookup_widget(objet,"spinbutton_quantitee_stock");
viande=lookup_widget(objet,"radiobutton_viande");
poulet=lookup_widget(objet,"radiobutton_poulet");
poisson=lookup_widget(objet,"radiobutton_Poisson");
fruit=lookup_widget(objet,"radiobutton_Fruit");
legume=lookup_widget(objet,"radiobutton_legume");
input1=lookup_widget(objet,"comboboxentry_ajout_stock");
if(x==1)
{
strcpy(s.categorie,"viande");
}
if(x==2)
{
strcpy(s.categorie,"poulet");
}
if(x==3)
{
strcpy(s.categorie,"poisson");
}
if(x==4)
{
strcpy(s.categorie,"fruit");
}
if(x==5)
{
strcpy(s.categorie,"legume");
}
if(x==6)
{
strcpy(s.categorie,"Boisson");
}
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
strcpy(s.id, gtk_entry_get_text(GTK_ENTRY(input)));
s.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(quantitee));


Ajouter_stock(s);


}


void
on_radiobutton_viande_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=1;
}


void
on_radiobutton_poulet_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=2;
}


void
on_radiobutton_Poisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=3;
}


void
on_radiobutton_Fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=4;
}


void
on_radiobutton_legume_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=5;
}


void
on_button_afficher_stock_clicked       (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_stock;
GtkWidget *treeview1;

fenetre_stock=lookup_widget(objet,"fenetre_stock");

fenetre_stock=create_fenetre_stock();

gtk_widget_show(fenetre_stock);

treeview1=lookup_widget(fenetre_stock,"treeview1");

afficher_stock(treeview1);
}


void
on_button_actualiser_stock_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_stock,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet,"fenetre_stock");
fenetre_stock=create_fenetre_stock();

gtk_widget_show(fenetre_stock);

gtk_widget_hide(w1);

treeview1=lookup_widget(fenetre_stock,"treeview1");

afficher_stock(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *categorie;
gchar *id;
gint *quantite;
stock s;


 GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&categorie,1,&id,2,&quantite,-1);
strcpy(s.categorie,categorie);
strcpy(s.id,id);
s.quantite=quantite;
Supprimer_stock(s);
afficher_stock(treeview);
}
}


void
on_button_chercher_stock_clicked       (GtkButton       *objet,
                                        gpointer         user_data)
{
stock s;
GtkWidget *input11;
GtkWidget *nonexiste;

input11=lookup_widget(objet,"entry_chercher_stock");
nonexiste=lookup_widget(objet,"label_chercher");


strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(input11)));

if (exist_id(s.id)==0)
{ 
    gtk_label_set_text(GTK_LABEL(nonexiste),"Produit en rupture");
}
else 
{
    gtk_label_set_text(GTK_LABEL(nonexiste),"ID existant");
}

chercher_stock(s);
 


gtk_entry_set_text(GTK_ENTRY(input11),"");
GtkWidget *treeview1;
treeview1=lookup_widget(objet,"treeview1");
afficher_stock_chercher(treeview1);
}


void
on_button5_clicked                     (GtkButton       *objet,
                                        gpointer         user_data)
{
stock s;


GtkWidget *input,*success,*input1,*input2;
input=lookup_widget(objet,"entry_modif_id_stock");
input1=lookup_widget(objet,"spinbutton1_quantite_stock");
success=lookup_widget(objet,"label_modifier_msg");
input2=lookup_widget(objet,"comboboxentry_modifier_stock");

strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(input)));

if (y==1)
{
strcpy(s.categorie,"viande");
}
if (y==2)
{
strcpy(s.categorie,"poulet");
}
if (y==3)
{
strcpy(s.categorie,"poisson");
}
if (y==4)
{
strcpy(s.categorie,"fruit");
}
if (y==5)
{
strcpy(s.categorie,"legume");
}
if (y==6)
{
strcpy(s.categorie,"Boisson");
}
s.quantite=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input1));
strcpy(s.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input2)));
gtk_label_set_text(GTK_LABEL(success),"Modification réuissite"); 

modifier_stock(s);
}


void
on_radiobutton1_viande_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=1;
}


void
on_radiobutton1_poulet_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=2;
}


void
on_radiobutton1_poisson_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=3;
}


void
on_radiobutton1_fruit_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=4;
}


void
on_radiobutton1_legume_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=5;
}


void
on_radiobutton_boisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=6;
}


void
on_radiobutton_modif_stock_boisson_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=6;
}


void
on_button_supprimer_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
stock s;
char id1[20],id2[20];
char n1[20] , n2[20];
int n3;
char msg [50];
int trouve=0;
FILE *f,*E ;
input1= lookup_widget (objet, "entry_supprimer");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(input1)));
f=fopen("stock.txt","r");
E=fopen("stocktemp.txt","w");
  while (fscanf (f, "%s %s %s %d ", &n1,&n2,&id2, &n3) == 4)
    if (strcmp (id2, id1) != 0)
      fprintf (E, "%s %s %s %d \n", n1,id2,n2, n3);
  fclose(f);
  fclose(E);
f=fopen("stock.txt","w");
E=fopen("stocktemp.txt","r");
  while (fscanf (E, "%s %s %s %d ", &n1,&n2,&id2, &n3) == 4)
      fprintf (f, "%s %s %s %d \n", n1,n2,id2, n3);
 fclose (f);
 fclose(E);
}

