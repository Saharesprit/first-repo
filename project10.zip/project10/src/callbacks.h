#include <gtk/gtk.h>


void
on_button_ajouter_stock_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_viande_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_poulet_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_Poisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_Fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_legume_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_afficher_stock_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_stock_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_chercher_stock_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_viande_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_poulet_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_poisson_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_fruit_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_legume_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_boisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modif_stock_boisson_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);
